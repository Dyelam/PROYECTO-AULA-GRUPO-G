package VistasEntidades;

import com.mycompany.migracionjavafx.Entidades.Servicio;
import com.mycompany.migracionjavafx.Entidades.TMultiservicio;
import com.mycompany.migracionjavafx.Entidades.TUnico;
import com.mycompany.migracionjavafx.Entidades.Tecnico;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author EQUIPO
 */
public class TecnicoVista {

    private SimpleStringProperty fechaIngreso;
    private SimpleStringProperty nombre;
    private SimpleStringProperty apellido;
    private SimpleStringProperty cedula;
    private SimpleStringProperty servicio;
    private SimpleStringProperty especialidad;

    public TecnicoVista(Tecnico t) {
        this.fechaIngreso = new SimpleStringProperty(t.getFechaIngreso().toString());
        this.nombre = new SimpleStringProperty(t.getNombre());
        this.apellido = new SimpleStringProperty(t.getApellido());
        this.cedula = new SimpleStringProperty(t.getCedula());
        
        if(t.getTipoTecnico().equals("Tecnico Multiservicio" )){
            String service="";
            TMultiservicio tech = (TMultiservicio) t;
            for(Servicio s:tech.getOficios() ){
                service=service+s.getNombreServicio()+"\n";
            }
             this.servicio = new SimpleStringProperty(service);
        }else{
            TUnico tuni=(TUnico) t;
             this.servicio = new SimpleStringProperty(tuni.getOficio().getNombreServicio());
        }
        this.especialidad = new SimpleStringProperty(t.getDetalle());
    }

    public String getFechaIngreso() {
        return fechaIngreso.get();
    }

    public String getNombre() {
        return nombre.get();
    }

    public String getApellido() {
        return apellido.get();
    }

    public String getCedula() {
        return cedula.get();
    }

    public String getEspecialidad() {
        return especialidad.get();
    }

    public String getServicio() {
        return servicio.get();
    }
}
