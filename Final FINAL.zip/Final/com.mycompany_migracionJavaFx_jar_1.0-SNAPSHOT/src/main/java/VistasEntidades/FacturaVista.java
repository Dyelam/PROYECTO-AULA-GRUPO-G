package VistasEntidades;

import com.mycompany.migracionjavafx.Entidades.Factura;
import com.mycompany.migracionjavafx.Entidades.Servicio;
import com.mycompany.migracionjavafx.Entidades.Tecnico;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author EQUIPO
 */
public class FacturaVista {

    private SimpleIntegerProperty noFactura;
    private SimpleStringProperty fechaFactura;
    private SimpleStringProperty nombreCliente;
    private SimpleStringProperty placa;
    private SimpleStringProperty modelo;
    private SimpleStringProperty marca;
    private SimpleStringProperty tecnico;
    private SimpleStringProperty servicio;
    private SimpleDoubleProperty valorFactura;

    public FacturaVista(Factura f) {
        this.noFactura = new SimpleIntegerProperty(f.getConsecutivo());
        this.fechaFactura = new SimpleStringProperty(f.getFecha().toString());
        this.nombreCliente = new SimpleStringProperty(f.getNomCliente());
        this.placa = new SimpleStringProperty(f.getAuto().getPlaca());
        this.marca = new SimpleStringProperty(f.getAuto().getMarca());
        this.modelo = new SimpleStringProperty(f.getAuto().getModelo());

        if (f.getServicios() != null) {
            String service = "";
            for (Servicio s : f.getServicios()) {
                service = service + s.getNombreServicio() + "\n";
            }
            this.servicio = new SimpleStringProperty(service);
        } else {
            this.servicio = new SimpleStringProperty(f.getServicio().getNombreServicio());
        }
        if(f.getTecnicos()!=null){
            String nombresTec="";
            for(Tecnico t:f.getTecnicos() ){
                nombresTec=nombresTec+" "+t.getNombre()+" "+t.getApellido()+"\n ";
            }
        this.tecnico = new SimpleStringProperty(nombresTec);
        }else{
        this.tecnico = new SimpleStringProperty(f.getTech().getNombre() + " " + f.getTech().getApellido());
        }
        this.valorFactura = new SimpleDoubleProperty(f.getPrecio());
    }

    public int getNoFactura() {
        return noFactura.get();
    }

    public String getFechaFactura() {
        return fechaFactura.get();
    }

    public String getNombreCliente() {
        return nombreCliente.get();
    }

    public String getPlaca() {
        return placa.get();
    }

    public String getModelo() {
        return modelo.get();
    }

    public String getMarca() {
        return marca.get();
    }

    public String getTecnico() {
        return tecnico.get();
    }

    public String getServicio() {
        return servicio.get();
    }

    public double getValorFactura() {
        return valorFactura.get();
    }

    @Override
    public String toString() {
        return "FacturaVista{" + "noFactura=" + noFactura + ", fechaFactura=" + fechaFactura + ", nombreCliente=" + nombreCliente + ", placa=" + placa + ", modelo=" + modelo + ", marca=" + marca + ", tecnico=" + tecnico + ", servicio=" + servicio + ", valorFactura=" + valorFactura + '}';
    }

}
