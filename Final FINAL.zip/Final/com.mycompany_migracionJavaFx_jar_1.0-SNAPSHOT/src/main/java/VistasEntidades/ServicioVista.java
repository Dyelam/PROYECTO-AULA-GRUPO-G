
package VistasEntidades;

import com.mycompany.migracionjavafx.Entidades.Servicio;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 
@author EQUIPO*/
public class ServicioVista {

    private SimpleDoubleProperty valorUnitario;
    private SimpleStringProperty servicio;


    public ServicioVista(Servicio s) {

        this.servicio = new SimpleStringProperty(s.getNombreServicio());

        this.valorUnitario = new SimpleDoubleProperty(s.getCosto());
    }

   
    public String getServicio() {
        return servicio.get();
    }

    public double getValorUnitario() {
        return valorUnitario.get();
    }
    
   

}