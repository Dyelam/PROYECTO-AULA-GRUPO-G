package VistasEntidades;

import com.mycompany.migracionjavafx.Entidades.Factura;
import com.mycompany.migracionjavafx.Entidades.Servicio;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class NominaVista {

    private SimpleIntegerProperty noFactura;
    private SimpleStringProperty fechaFactura;
    private SimpleStringProperty servicio;
    private SimpleStringProperty porcentaje;
    private SimpleStringProperty valorFactura;

    public NominaVista(Factura f) {
        this.noFactura = new SimpleIntegerProperty(f.getConsecutivo());
        this.fechaFactura = new SimpleStringProperty(f.getFecha().toString());
        String service = "";
        String porcentajes = "";
        String costo = "";
        if (f.getServicios() != null) {
            for (Servicio s : f.getServicios()) {
                service = service + s.getNombreServicio() + "\n";
                porcentajes = porcentajes + Integer.toString((int) (100 * s.getPorcentaje())) + "\n";
                costo = costo + s.getCosto() + "\n";
            }
            this.servicio = new SimpleStringProperty(service);
            this.porcentaje = new SimpleStringProperty(porcentajes);
            this.valorFactura = new SimpleStringProperty(costo);
        } else {
            this.servicio = new SimpleStringProperty(f.getServicio().getNombreServicio());
            this.porcentaje = new SimpleStringProperty(Integer.toString((int) (100*f.getServicio().getPorcentaje())));
            this.valorFactura = new SimpleStringProperty(Double.toString(f.getPrecio()));
        }

    }

    public int getNoFactura() {
        return noFactura.get();
    }

    public String getFechaFactura() {
        return fechaFactura.get();
    }

    public String getServicio() {
        return servicio.get();
    }

    public String getPorcentaje() {
        return porcentaje.get();
    }

    public String getValorFactura() {
        return valorFactura.get();
    }

}
