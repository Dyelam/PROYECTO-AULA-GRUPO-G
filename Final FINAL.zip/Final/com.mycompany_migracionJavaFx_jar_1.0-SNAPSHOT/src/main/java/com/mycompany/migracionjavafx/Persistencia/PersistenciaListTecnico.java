/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.migracionjavafx.Persistencia;

/**
 *
 * @author EQUIPO
 */
public class PersistenciaListTecnico {
    private static IListaTecnico data3;
    
    private PersistenciaListTecnico(){
        data3 = new ListaTecnico();
    }
    
    public static IListaTecnico get(){
        if(data3==null){
            new PersistenciaListTecnico();
        }
        
        return data3;
    }
}

