package com.mycompany.migracionjavafx.contralador;

import VistasEntidades.Mensaje;
import com.mycompany.migracionjavafx.Entidades.Alineacion;
import com.mycompany.migracionjavafx.Entidades.Balanceo;
import com.mycompany.migracionjavafx.Entidades.CalibrarValvulas;
import com.mycompany.migracionjavafx.Entidades.Factura;
import com.mycompany.migracionjavafx.Entidades.Servicio;
import com.mycompany.migracionjavafx.Entidades.Sincronizacion;
import com.mycompany.migracionjavafx.Entidades.TMultiservicio;
import com.mycompany.migracionjavafx.Entidades.TUnico;
import com.mycompany.migracionjavafx.Entidades.Tecnico;
import com.mycompany.migracionjavafx.Logica.LogicaEmpleado;
import com.mycompany.migracionjavafx.Logica.LogicaFactura;
import com.mycompany.migracionjavafx.Logica.LogicaServicio;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class CrearFactura implements Initializable {

    @FXML
    private Button btnCancelar;

    @FXML
    private Button btnRegistrar;

    @FXML
    private CheckBox cbAlineacion;

    @FXML
    private CheckBox cbBalanceo;

    @FXML
    private CheckBox cbCalibrarValvulas;

    @FXML
    private CheckBox cbSincronizacion;

    @FXML
    private ComboBox<String> cmbAlineador;

    @FXML
    private ComboBox<String> cmbBalanceo;

    @FXML
    private ComboBox<String> cmbCalibrador;

    @FXML
    private ComboBox<Integer> cmbNoCilindros;

    @FXML
    private ComboBox<Integer> cmbNumeroLlantas;

    @FXML
    private ComboBox<String> cmbSincronizador;

    @FXML
    private ComboBox<Integer> cmbTamañoRing;

    @FXML
    private ComboBox<String> cmbVehiculo;

    @FXML
    private DatePicker dpFecha;

    @FXML
    private TextField txtMarca;

    @FXML
    private TextField txtModelo;

    @FXML
    private TextField txtNoFactura;

    @FXML
    private TextField txtNombreCliente;

    @FXML
    private TextField txtPlaca;

    private LogicaEmpleado logicaTecnico = new LogicaEmpleado();
    private LogicaFactura logicaFactura = new LogicaFactura();
    private LogicaServicio logicaServicio = new LogicaServicio();

    private ObservableList<Integer> listNumCil = FXCollections.observableArrayList();
    private ObservableList<Integer> listRing = FXCollections.observableArrayList();
    private ObservableList<Integer> listLlantas = FXCollections.observableArrayList();
    private ObservableList<String> listTVeh = FXCollections.observableArrayList();
    private ObservableList<String> listAlineador = FXCollections.observableArrayList();
    private ObservableList<String> listBalanceo = FXCollections.observableArrayList();
    private ObservableList<String> listCalibrador = FXCollections.observableArrayList();
    private ObservableList<String> listSincronizador = FXCollections.observableArrayList();

    LocalDate fecha = LocalDate.now();
    Servicio servicio1 = new Balanceo(" ", 0.3, 7, 15);
    Servicio servicio2 = new Sincronizacion(" ", 0.4, 120, 150, 180);
    Servicio servicio3 = new Alineacion(" ", 0.3, 30, 25);
    Servicio servicio4 = new CalibrarValvulas(" ", 0.5, 100, 130);
    Tecnico tecnico1 = new TUnico("Tecnico monoServicio", servicio2, "Jose", "Vidal", "1044", fecha, "Sincronizador");
    TMultiservicio tecnico2 = new TMultiservicio("Tecnico Multiservicio", "Juan", "Taborda", "1066", fecha, "Alineador");

    public void Registro() {
        this.logicaServicio.registrarServicio(servicio1);
        this.logicaServicio.registrarServicio(servicio2);
        this.logicaServicio.registrarServicio(servicio3);

        this.logicaTecnico.registrarEmpleado(tecnico1);
        tecnico2.addServicio(servicio1);
        tecnico2.addServicio(servicio3);
        Tecnico tecnico = tecnico2;
        this.logicaTecnico.registrarEmpleado(tecnico);
        this.logicaServicio.registrarServicio(servicio4);
    }

    @FXML
    void clickRegistrar(ActionEvent event) {
        Factura nuevaFactura = null;
        LocalDate fechaFactura = null;
        int noFactura = 0;
        String nombreCliente = "";
        String tVehiculo = "";
        String placa = "";
        String marca = "";
        String modelo = "";
        String alineador = "";
        String balanceador = "";
        String calibrador = "";
        String sincronizador = "";
        int noCilindros = 0;
        int ring = 0;
        int llantas = 0;
        String svSincronizacion = "";
        String svAlineacion = "";
        String svBalanceo = "";
        String svCalibrarValvulas = "";
        ArrayList<Tecnico> tecnicos = new ArrayList();
        ArrayList<String> nombreServicio = new ArrayList();
        ArrayList<Servicio> servicios = new ArrayList();
        Tecnico tech = null;
        int numero = 0;
        try {

            noFactura = Integer.parseInt(this.txtNoFactura.getText());
        } catch (NumberFormatException npe) {
            numero = 0;
        }
        for (Factura f : this.logicaFactura.consultarFacturas()) {
            numero = f.getConsecutivo();
        }

        fechaFactura = this.dpFecha.getValue();
        nombreCliente = this.txtNombreCliente.getText();
        tVehiculo = this.cmbVehiculo.getSelectionModel().getSelectedItem();
        placa = this.txtPlaca.getText();
        marca = this.txtMarca.getText();
        modelo = this.txtModelo.getText();
        if (this.cbSincronizacion.isSelected()) {
            svSincronizacion = this.cbSincronizacion.getText();
            System.out.println(svSincronizacion);
        }

        if (this.cbAlineacion.isSelected()) {
            svAlineacion = this.cbAlineacion.getText();
        }

        if (this.cbBalanceo.isSelected()) {
            svBalanceo = this.cbBalanceo.getText();
        }

        if (this.cbCalibrarValvulas.isSelected()) {
            svCalibrarValvulas = this.cbCalibrarValvulas.getText();
        }
        nombreServicio.add(svSincronizacion);
        nombreServicio.add(svBalanceo);
        nombreServicio.add(svAlineacion);
        nombreServicio.add(svCalibrarValvulas);
        try {
            noCilindros = this.cmbNoCilindros.getValue();
        } catch (NullPointerException npe) {
            noCilindros = 0;
        }
        try {
            ring = this.cmbTamañoRing.getValue();
        } catch (NullPointerException npe) {
            ring = 0;
        }
        try {
            llantas = this.cmbNumeroLlantas.getValue();
        } catch (NullPointerException npe) {
            llantas = 0;
        }
        try {
            String[] aline = this.cmbAlineador.getValue().split("\\s+");
            alineador = aline[0];
        } catch (NullPointerException npe) {
            alineador = "";
        }
        try {
            String[] balan = this.cmbBalanceo.getValue().split("\\s+");
            balanceador = balan[0];
        } catch (NullPointerException npe) {
            balanceador = "";
        }
        try {
            String[] cali = this.cmbCalibrador.getValue().split("\\s+");
            calibrador = cali[0];
        } catch (NullPointerException npe) {
            calibrador = "";
        }
        try {
            String[] sincro = this.cmbSincronizador.getValue().split("\\s+");
            sincronizador = sincro[0];
        } catch (NullPointerException npe) {
            sincronizador = "";
        }
        if (numero < noFactura) {
            ArrayList<String> cedulas = new ArrayList();
            cedulas.add(alineador);
            cedulas.add(balanceador);
            cedulas.add(calibrador);
            cedulas.add(sincronizador);
            ArrayList<String> ced = this.eliminarRepetidos(cedulas);
            for (Tecnico t : this.logicaTecnico.consultarTecnico()) {
                for (String cc : ced) {
                    if (t.getCedula().equals(cc)) {
                        tecnicos.add(t);
                    }
                }
            }

            for (Servicio s : this.logicaServicio.consultarServicios()) {
                for (String ns : nombreServicio) {
                    if (s.getNombreServicio().equals(ns)) {
                        servicios.add(s);
                    }
                }
            }
            if (tecnicos.size() == 1 && servicios.size() == 1) {
                for (Tecnico te : tecnicos) {
                    tech = te;
                }
                Servicio servi = null;
                for (Servicio s : servicios) {
                    servi = s;
                }
                try {
                    nuevaFactura = this.logicaFactura.crearFactura(nombreCliente, fechaFactura, tVehiculo, placa, marca, modelo, noCilindros, ring, tech, servi);
//          nuevaFactura = new Factura(nombreCliente, fechaFactura, tVehiculo, placa, marca, modelo, noCilindros, ring, tech, servi);
                    nuevaFactura.setConsecutivo(noFactura);
                    String nombreService = servi.getNombreServicio();

                    //Sincronizacion
                    if (nombreService.equals("Sincronización")) {
                        Sincronizacion serv = (Sincronizacion) servi;
                        serv.calcularCosto(noCilindros);
                        nuevaFactura.calcularCostoUnicoServicio();
                        this.logicaFactura.registrarFactura(nuevaFactura);
                    }

                    //Alineacion
                    if (nombreService.equals("Alineación")) {
                        Alineacion serv = (Alineacion) servi;
                        int tv = 0;
                        if (tVehiculo.equals("Camioneta")) {
                            tv = 1;
                        }
                        serv.calcularCosto(tv);
                        nuevaFactura.calcularCostoUnicoServicio();
                        this.logicaFactura.registrarFactura(nuevaFactura);
                    }

                    //Balanceo 
                    if (nombreService.equals("Balanceo")) {
                        Balanceo serv = (Balanceo) servi;
                        serv.calcularCosto(llantas, ring);
                        nuevaFactura.calcularCostoUnicoServicio();
                        this.logicaFactura.registrarFactura(nuevaFactura);
                    }

                    //Calibrar Valvulas
                    if (nombreService.equals("Calibrar Válvulas")) {
                        CalibrarValvulas serv = (CalibrarValvulas) servi;
                        serv.calcularCosto(noCilindros);
                        nuevaFactura.calcularCostoUnicoServicio();
                        this.logicaFactura.registrarFactura(nuevaFactura);
                    }
                    this.limpiarComponentes();
                    Mensaje.notificarMensaje("Registro existoso", "La factura ha sido registrada con exito", Alert.AlertType.INFORMATION);
                } catch (IllegalArgumentException ae) {
                    Mensaje.notificarMensaje("Campos vacios", "Rellene los campos vacios ", Alert.AlertType.ERROR);
                }
            }
            if (tecnicos.size() == 1 && servicios.size() > 1) {
                for (Tecnico te : tecnicos) {
                    tech = te;
                }
                try {
                    TMultiservicio tM = (TMultiservicio) tech;
                    nuevaFactura = this.logicaFactura.crearFactura(nombreCliente, fechaFactura, tVehiculo, placa, marca, modelo, noCilindros, ring, tM, servicios);
                    //nuevaFactura = new Factura(nombreCliente, fechaFactura, tVehiculo, placa, marca, modelo, noCilindros, ring, tech, servicios);
                    nuevaFactura.setConsecutivo(noFactura);
                    for (Servicio s1 : nuevaFactura.getServicios()) {
                        //Sincronizacion
                        System.out.println(s1.toString());
                        if (s1.getNombreServicio().equals("Sincronización")) {
                            Sincronizacion sincr = (Sincronizacion) s1;
                            sincr.calcularCosto(noCilindros);
                        }

                        //Alineacion
                        if (s1.getNombreServicio().equals("Alineación")) {
                            Alineacion alinea = (Alineacion) s1;
                            int tv = 0;
                            if (tVehiculo.equals("Camioneta")) {
                                tv = 1;
                            }
                            alinea.calcularCosto(tv);
                        }

                        //Balanceo 
                        if (s1.getNombreServicio().equals("Balanceo")) {
                            Balanceo balanceo = (Balanceo) s1;
                            balanceo.calcularCosto(llantas, ring);
                        }
                        //Calibrar Valvulas
                        if (s1.getNombreServicio().equals("Calibrar Válvulas")) {
                            CalibrarValvulas calib = (CalibrarValvulas) s1;
                            calib.calcularCosto(noCilindros);
                        }
                    }
                    nuevaFactura.calcularCostoMultiServicios();
                    this.logicaFactura.registrarFactura(nuevaFactura);
                    this.limpiarComponentes();
                    Mensaje.notificarMensaje("Registro existoso", "La factura ha sido registrada con exito", Alert.AlertType.INFORMATION);
                } catch (IllegalArgumentException ae) {
                    Mensaje.notificarMensaje("Campos vacios", "Rellene los campos vacios ", Alert.AlertType.ERROR);

                }
            }

            if (tecnicos.size() > 1 && servicios.size() > 1) {
                try {
                    nuevaFactura = this.logicaFactura.crearFactura(nombreCliente, fechaFactura, tVehiculo, placa, marca, modelo, noCilindros, ring, tecnicos, servicios);
                    //nuevaFactura = new Factura(nombreCliente, fechaFactura, tVehiculo, placa, marca, modelo, noCilindros, ring, tecnicos, servicios);
                    nuevaFactura.setConsecutivo(noFactura);
                    for (Servicio s1 : nuevaFactura.getServicios()) {
                        //Sincronizacion
                        System.out.println(s1.toString());
                        if (s1.getNombreServicio().equals("Sincronización")) {
                            Sincronizacion sincr = (Sincronizacion) s1;
                            sincr.calcularCosto(noCilindros);
                        }

                        //Alineacion
                        if (s1.getNombreServicio().equals("Alineación")) {
                            Alineacion alinea = (Alineacion) s1;
                            int tv = 0;
                            if (tVehiculo.equals("Camioneta")) {
                                tv = 1;
                            }
                            alinea.calcularCosto(tv);
                        }

                        //Balanceo 
                        if (s1.getNombreServicio().equals("Balanceo")) {
                            Balanceo balanceo = (Balanceo) s1;
                            balanceo.calcularCosto(llantas, ring);
                        }
                        //Calibrar Valvulas
                        if (s1.getNombreServicio().equals("Calibrar Válvulas")) {
                            CalibrarValvulas calib = (CalibrarValvulas) s1;
                            calib.calcularCosto(noCilindros);
                        }
                    }
                    nuevaFactura.calcularCostoMultiServicios();
                    this.logicaFactura.registrarFactura(nuevaFactura);
                    this.limpiarComponentes();
                    Mensaje.notificarMensaje("Registro existoso", "La factura ha sido registrada con exito", Alert.AlertType.INFORMATION);
                    //  this.limpiarComponentes();
                } catch (IllegalArgumentException ae) {
                    Mensaje.notificarMensaje("Campos vacios", "Rellene los campos vacios ", Alert.AlertType.ERROR);
                }

            }

        } else {
            Mensaje.notificarMensaje("Numero ya registrado", "El numero de la factura ya ha sido registrado o está el campo vacío, intente nuevamente", Alert.AlertType.INFORMATION);
        }
    }

    private ArrayList<String> eliminarRepetidos(ArrayList<String> listaConRepetidos) {
        Set<String> set = new HashSet<>(listaConRepetidos);
        return new ArrayList<>(set);
    }

    @FXML
    void clickAlineacion(ActionEvent event) {
        if (this.cbAlineacion.isSelected()) {
            this.cmbAlineador.setDisable(false);
        } else {
            this.cmbAlineador.setDisable(true);
        }
    }

    @FXML
    void clickBalanceo(ActionEvent event) {
        if (this.cbBalanceo.isSelected()) {
            this.cmbBalanceo.setDisable(false);
            this.cmbNumeroLlantas.setDisable(false);
        } else {
            this.cmbBalanceo.setDisable(true);
            this.cmbNumeroLlantas.setDisable(true);
        }
    }

    @FXML
    void clickCalibrar(ActionEvent event) {
        if (this.cbCalibrarValvulas.isSelected()) {
            this.cmbCalibrador.setDisable(false);
        } else {
            this.cmbCalibrador.setDisable(true);

        }
    }

    @FXML
    void clickCancelar(ActionEvent event) {
        this.limpiarComponentes();
    }

    @FXML
    void clickSincronizacion(ActionEvent event) {
        if (this.cbSincronizacion.isSelected()) {
            this.cmbSincronizador.setDisable(false);
        } else {
            this.cmbSincronizador.setDisable(true);
        }
    }

    public void limpiarComponentes() {
        this.dpFecha.setValue(null);
        this.txtMarca.setText(null);
        this.txtModelo.setText(null);
        this.txtNoFactura.setText(null);
        this.txtNombreCliente.setText(null);
        this.txtPlaca.setText(null);
        this.cbAlineacion.setSelected(false);
        this.cbBalanceo.setSelected(false);
        this.cbCalibrarValvulas.setSelected(false);
        this.cbSincronizacion.setSelected(false);
        this.cmbVehiculo.setValue(null);
        this.cmbNoCilindros.setValue(null);
        this.cmbTamañoRing.setValue(null);
        this.cmbNumeroLlantas.setValue(null);
        this.cmbAlineador.setValue(null);
        this.cmbBalanceo.setValue(null);
        this.cmbCalibrador.setValue(null);
        this.cmbSincronizador.setValue(null);
         this.cmbAlineador.setDisable(true);
        this.cmbBalanceo.setDisable(true);
        this.cmbCalibrador.setDisable(true);
        this.cmbSincronizador.setDisable(true);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        this.listTVeh.addAll("Camioneta ", "Automóvil");
        this.cmbVehiculo.setItems(listTVeh);
        this.listRing.addAll(13, 14, 15, 16, 17, 18);
        this.cmbTamañoRing.setItems(listRing);
        this.listNumCil.addAll(3, 4, 6);
        this.cmbNoCilindros.setItems(listNumCil);
        this.listLlantas.addAll(1, 2, 3, 4);
        this.cmbNumeroLlantas.setItems(listLlantas);
        //this.Registro();

        for (Tecnico t : this.logicaTecnico.consultarTecnico()) {
            if (t.getDetalle().equals("Alineador")) {
                this.listAlineador.add(t.getCedula() + " " + t.getNombre() + " " + t.getApellido());
            }
            if (t.getDetalle().equals("Alineador")) {
                this.listBalanceo.add(t.getCedula() + " " + t.getNombre() + " " + t.getApellido());
            }
            if (t.getDetalle().equals("Calibrador")) {
                this.listCalibrador.add(t.getCedula() + " " + t.getNombre() + " " + t.getApellido());
            }
            if (t.getDetalle().equals("Sincronizador")) {
                this.listSincronizador.add(t.getCedula() + " " + t.getNombre() + " " + t.getApellido());
            }
        }
        this.cmbAlineador.setItems(listAlineador);
        this.cmbBalanceo.setItems(listBalanceo);
        this.cmbCalibrador.setItems(listCalibrador);
        this.cmbSincronizador.setItems(listSincronizador);

        this.cmbAlineador.setDisable(true);
        this.cmbBalanceo.setDisable(true);
        this.cmbCalibrador.setDisable(true);
        this.cmbNumeroLlantas.setDisable(true);
        this.cmbSincronizador.setDisable(true);

    }

}
