
package com.mycompany.migracionjavafx.Entidades;

public class Login {
    private String contraseña;
    
    public Login(){
        this.contraseña="1234";
    }
    public Login(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public boolean validarContraseña(String contraseñaIngresada) {
        return this.contraseña.equals(contraseñaIngresada);
    }

    
    }

