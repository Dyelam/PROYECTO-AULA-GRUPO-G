/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.migracionjavafx.Persistencia;

/**
 *
 * @author EQUIPO
 */
public class PersistenciaListFactura {
    private static IListaFactura data;
    
    private PersistenciaListFactura(){
        data = new ListaFactura();
    }
    
    public static IListaFactura get(){
        if(data==null){
            new PersistenciaListFactura();
        }
        
        return data;
    }
}