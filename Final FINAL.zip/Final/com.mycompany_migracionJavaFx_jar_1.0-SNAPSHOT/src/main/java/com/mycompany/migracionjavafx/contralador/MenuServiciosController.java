package com.mycompany.migracionjavafx.contralador;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import com.mycompany.migracionjavafx.App;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author EQUIPO
 */
public class MenuServiciosController implements Initializable {

    @FXML
    private Button btnConsustar;
    @FXML
    private Button btnModificar;
    @FXML
    private Button btnMenuPrincipal;
    @FXML
    private StackPane panelOpciones;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    
    @FXML
    private void clickConsultar(ActionEvent event) throws IOException {
         this.panelOpciones.getChildren().clear();
        StackPane pane = new StackPane(App.loadFXML("ConsultarServicio"));
        this.panelOpciones.getChildren().add(pane);
    }

    @FXML
    private void clickModificar(ActionEvent event) throws IOException {
        this.panelOpciones.getChildren().clear();
        StackPane pane = new StackPane(App.loadFXML("ModificarServicio"));
        this.panelOpciones.getChildren().add(pane);
    }

    @FXML
    private void clickMenuPrincipal(ActionEvent event) throws IOException {
         App.newStage("MenuPrincipal", true, 1240, 720);
    }
    
}
