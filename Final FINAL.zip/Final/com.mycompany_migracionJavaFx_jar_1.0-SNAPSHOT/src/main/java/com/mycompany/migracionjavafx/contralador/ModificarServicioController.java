/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.migracionjavafx.contralador;

import VistasEntidades.Mensaje;
import com.mycompany.migracionjavafx.Entidades.Alineacion;
import com.mycompany.migracionjavafx.Entidades.Balanceo;
import com.mycompany.migracionjavafx.Entidades.CalibrarValvulas;
import com.mycompany.migracionjavafx.Entidades.Servicio;
import com.mycompany.migracionjavafx.Entidades.Sincronizacion;
import com.mycompany.migracionjavafx.Logica.LogicaServicio;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author EQUIPO
 */
public class ModificarServicioController implements Initializable {

    @FXML
    private CheckBox cbSincronizacion;
    @FXML
    private CheckBox cbBalanceo;
    @FXML
    private CheckBox cbAlineacion;
    @FXML
    private CheckBox cbCalibrar;
    @FXML
    private TextArea txtDescripcion;
    @FXML
    private TextField txtPorcentaje;
    @FXML
    private TextField txtPrecio1;
    @FXML
    private TextField txtPrecio2;
    @FXML
    private TextField txtPrecio3;
    @FXML
    private Button btnMdificar;
    @FXML
    private Button btnCancelar;
    @FXML
    private Label lbPrecio1, lbPrecio2;

    private LogicaServicio logicaServicio = new LogicaServicio();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void clickSincronizacion(ActionEvent event) {
        if (this.cbSincronizacion.isSelected()) {
            this.cbAlineacion.setDisable(true);
            this.cbBalanceo.setDisable(true);
            this.cbCalibrar.setDisable(true);
            Servicio servi = null;
            for (Servicio s : this.logicaServicio.consultarServicios()) {
                if (s.getNombreServicio().equals("Sincronización")) {
                    servi = s;
                }
            }
            this.txtDescripcion.setText(servi.getDescripcion());
            this.txtPorcentaje.setText(Integer.toString((int) (100 * servi.getPorcentaje())));
            Sincronizacion sincro = (Sincronizacion) servi;
            this.lbPrecio1.setText("Precio por número de cilindros [3-4]");
            this.txtPrecio1.setText(Double.toString(sincro.getPrecio1()));
            this.lbPrecio2.setText("Precio por número de cilindros[6]");
            this.txtPrecio2.setText(Double.toString(sincro.getPrecio2()));
        } else {
            this.cbAlineacion.setDisable(false);
            this.cbBalanceo.setDisable(false);
            this.cbCalibrar.setDisable(false);
        }

    }

    @FXML
    private void clickBalanceo(ActionEvent event) {
        if (this.cbBalanceo.isSelected()) {
            this.cbAlineacion.setDisable(true);
            this.cbSincronizacion.setDisable(true);
            this.cbCalibrar.setDisable(true);
            Servicio servi = null;
            for (Servicio s : this.logicaServicio.consultarServicios()) {
                if (s.getNombreServicio().equals("Balanceo")) {
                    servi = s;
                }
            }
            this.txtDescripcion.setText(servi.getDescripcion());
            this.txtPorcentaje.setText(Integer.toString((int) (100 * servi.getPorcentaje())));
            Balanceo balanceo = (Balanceo) servi;
            this.lbPrecio1.setText("Precio por tamaño de ring [13-14]");
            this.txtPrecio1.setText(Double.toString(balanceo.getPrecio1()));
            this.lbPrecio2.setText("Precio por tamaño de ring [15-18]");
            this.txtPrecio2.setText(Double.toString(balanceo.getPrecio2()));
        } else {
            this.cbAlineacion.setDisable(false);
            this.cbSincronizacion.setDisable(false);
            this.cbCalibrar.setDisable(false);
        }
    }

    @FXML
    private void clickAlineacion(ActionEvent event) {
        if (this.cbAlineacion.isSelected()) {
            this.cbBalanceo.setDisable(true);
            this.cbSincronizacion.setDisable(true);
            this.cbCalibrar.setDisable(true);
            Servicio alinea = null;
            for (Servicio s : this.logicaServicio.consultarServicios()) {
                if (s.getNombreServicio().equals("Alineación")) {
                    alinea = s;
                }
            }
            this.txtDescripcion.setText(alinea.getDescripcion());
            this.txtPorcentaje.setText(Integer.toString((int) (100 * alinea.getPorcentaje())));
            Alineacion a = (Alineacion) alinea;
            this.lbPrecio1.setText("Precio por Camioneta");
            this.txtPrecio1.setText(Double.toString(a.getPrecio1()));
            this.lbPrecio2.setText("Precio por Automóvil");
            this.txtPrecio2.setText(Double.toString(a.getPrecio2()));

        } else {
            this.cbBalanceo.setDisable(false);
            this.cbSincronizacion.setDisable(false);
            this.cbCalibrar.setDisable(false);
        }
    }

    @FXML
    private void clickCalibrar(ActionEvent event) {
        if (this.cbCalibrar.isSelected()) {
            this.cbBalanceo.setDisable(true);
            this.cbSincronizacion.setDisable(true);
            this.cbAlineacion.setDisable(true);
            Servicio ser = null;
            for (Servicio s : this.logicaServicio.consultarServicios()) {
                if (s.getNombreServicio().equals("Calibrar Válvulas")) {
                    ser = s;
                }
            }
            this.txtDescripcion.setText(ser.getDescripcion());
            this.txtPorcentaje.setText(Integer.toString((int) (100 * ser.getPorcentaje())));
            CalibrarValvulas cva = (CalibrarValvulas) ser;
            this.lbPrecio1.setText("Precio por número de cilindros [3-4]");
            this.txtPrecio1.setText(Double.toString(cva.getPrecio1()));
            this.lbPrecio2.setText("Precio por número de cilindros[6]");
            this.txtPrecio2.setText(Double.toString(cva.getPrecio2()));
        } else {
            this.cbBalanceo.setDisable(false);
            this.cbSincronizacion.setDisable(false);
            this.cbAlineacion.setDisable(false);

        }
    }

    @FXML
    private void clickModificar(ActionEvent event) {
        String descripcion = this.txtDescripcion.getText();
        int porc = Integer.parseInt(this.txtPorcentaje.getText());
        double porcentaje = porc / 100;
        double precio1 = Double.parseDouble(this.txtPrecio1.getText());
        double precio2 = Double.parseDouble(this.txtPrecio2.getText());
        if (this.cbAlineacion.isSelected()) {
            Alineacion a = null;
            for (Servicio s : logicaServicio.consultarServicios()) {
                if (s.getNombreServicio().equals("Alineación")) {
                    a = (Alineacion) s;
                }
            }
            a.setDescripcion(descripcion);
            a.setPorcentaje(porcentaje);
            a.setPrecio1(precio1);
            a.setPrecio2(precio2);
            Mensaje.notificarMensaje("Modificación realizada", "Modificacion realizada con exito", Alert.AlertType.INFORMATION);

        }
        if (this.cbBalanceo.isSelected()) {
            Balanceo b = null;
            for (Servicio s : logicaServicio.consultarServicios()) {
                if (s.getNombreServicio().equals("Balanceo")) {
                    b = (Balanceo) s;
                }
            }
            b.setDescripcion(descripcion);
            b.setPorcentaje(porcentaje);
            b.setPrecio1(precio1);
            b.setPrecio2(precio2);
            Mensaje.notificarMensaje("Modificación realizada", "Modificacion realizada con exito", Alert.AlertType.INFORMATION);
        }
        if (this.cbSincronizacion.isSelected()) {
            Sincronizacion sin = null;
            for (Servicio s : logicaServicio.consultarServicios()) {
                if (s.getNombreServicio().equals("Sincronización")) {
                    sin = (Sincronizacion) s;
                }
            }
            sin.setDescripcion(descripcion);
            sin.setPorcentaje(porcentaje);
            sin.setPrecio1(precio1);
            sin.setPrecio2(precio2);
            Mensaje.notificarMensaje("Modificación realizada", "Modificacion realizada con exito", Alert.AlertType.INFORMATION);
        }

        if (this.cbCalibrar.isSelected()) {
            CalibrarValvulas c = null;
            for (Servicio s : logicaServicio.consultarServicios()) {
                if (s.getNombreServicio().equals("Calibrar Válvulas")) {
                    c = (CalibrarValvulas) s;
                }
            }
            c.setDescripcion(descripcion);
            c.setPorcentaje(porcentaje);
            c.setPrecio1(precio1);
            c.setPrecio2(precio2);
            Mensaje.notificarMensaje("Modificación realizada", "Modificacion realizada con exito", Alert.AlertType.INFORMATION);
        }
    }

    public void LimipiarItems() {
        this.txtDescripcion.setText(null);
        this.txtPorcentaje.setText(null);
        this.txtPrecio1.setText(null);
        this.txtPrecio2.setText(null);
        this.txtPrecio3.setText(null);
        this.cbAlineacion.setSelected(false);
        this.cbBalanceo.setSelected(false);
        this.cbCalibrar.setSelected(false);
        this.cbSincronizacion.setSelected(false);
    }

    @FXML
    private void clickCancelar(ActionEvent event) {

    }

}
