/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.migracionjavafx.contralador;

import VistasEntidades.Dialogo;
import VistasEntidades.Mensaje;
import com.mycompany.migracionjavafx.Entidades.Alineacion;
import com.mycompany.migracionjavafx.Entidades.Balanceo;
import com.mycompany.migracionjavafx.Entidades.Servicio;
import com.mycompany.migracionjavafx.Entidades.Sincronizacion;
import com.mycompany.migracionjavafx.Entidades.TMultiservicio;
import com.mycompany.migracionjavafx.Entidades.TUnico;
import com.mycompany.migracionjavafx.Entidades.Tecnico;
import com.mycompany.migracionjavafx.Logica.LogicaEmpleado;
import com.mycompany.migracionjavafx.Logica.LogicaServicio;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class ConsultarTecnicoController implements Initializable {

    @FXML
    private Button btnBuscar;

    @FXML
    private Button btnCancelar;

    @FXML
    private Button btnEliminar;

    @FXML
    private Label lbApellido;

    @FXML
    private Label lbApellidos;

    @FXML
    private Label lbCc;

    @FXML
    private Label lbCedula;

    @FXML
    private Label lbEspeci;

    @FXML
    private Label lbEspecialidad;

    @FXML
    private Label lbFIngreso;

    @FXML
    private Label lbFecha;

    @FXML
    private Label lbNombre;

    @FXML
    private Label lbNombres;

    @FXML
    private Label lbServi;

    @FXML
    private Label lbServicio;

    @FXML
    private TextField txtCedula;

    private LogicaEmpleado logicaTecnico = new LogicaEmpleado();

    private LogicaServicio logicaServicio = new LogicaServicio();
    String cc = "";

    @FXML
    void clickBuscar(ActionEvent event) {

        cc = this.txtCedula.getText();
        Tecnico tecnico = this.logicaTecnico.buscarTecnico(cc);
        if (tecnico == null) {
            Mensaje.notificarMensaje("No existe", "No existen coincidencias", Alert.AlertType.INFORMATION);
        } else {
            this.ocultarItems(true);
            this.lbCedula.setText(tecnico.getCedula());
            this.lbNombre.setText(tecnico.getNombre());
            this.lbApellido.setText(tecnico.getApellido());
            this.lbFecha.setText(tecnico.getFechaIngreso().toString());
            {
                this.lbEspecialidad.setText(tecnico.getDetalle());
                if (tecnico.getTipoTecnico().equals("Tecnico Multiservicio")) {
                    TMultiservicio tMul = (TMultiservicio) tecnico;
                    String service = "";
                    for (Servicio s : tMul.getOficios()) {
                        service = service + " " + s.getNombreServicio() + " ";
                    }
                    this.lbServicio.setText(service);
                } else {
                    TUnico tUni = (TUnico) tecnico;
                    this.lbServicio.setText(tUni.getOficio().getNombreServicio());
                }

            }
        }
    }

    @FXML
    void clickEliminar() {
        ButtonType confirmacion = Dialogo.Dialogo("Confirmar", "¿Estás seguro de despedir al tecnico?");
        if (confirmacion.getText().equals("Sí")) {
            this.logicaTecnico.eliminarTecnico(cc);
            Mensaje.notificarMensaje("Confimacion de eliminado", "Eliminado con exito", Alert.AlertType.INFORMATION);
         this.ocultarItems(false);
         this.txtCedula.setText(null);
        }
        
    }

    private void ocultarItems(boolean modo) {
        this.lbApellidos.setVisible(modo);
        this.btnEliminar.setVisible(modo);
        this.lbApellido.setVisible(modo);
        this.lbApellidos.setVisible(modo);
        this.lbCc.setVisible(modo);
        this.lbCedula.setVisible(modo);
        this.lbEspeci.setVisible(modo);
        this.lbEspecialidad.setVisible(modo);
        this.lbFIngreso.setVisible(modo);
        this.lbFecha.setVisible(modo);
        this.lbNombre.setVisible(modo);
        this.lbNombres.setVisible(modo);
        this.lbServi.setVisible(modo);
        this.lbServicio.setVisible(modo);
    }

    @FXML
    void clickCancelar(ActionEvent event) {
     this.ocultarItems(false);
     this.txtCedula.setText(null);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
     this.ocultarItems(false);
    }

}
