/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.migracionjavafx.contralador;

import VistasEntidades.Mensaje;
import com.mycompany.migracionjavafx.Entidades.Alineacion;
import com.mycompany.migracionjavafx.Entidades.Balanceo;
import com.mycompany.migracionjavafx.Entidades.Servicio;
import com.mycompany.migracionjavafx.Entidades.Sincronizacion;
import com.mycompany.migracionjavafx.Entidades.TMultiservicio;
import com.mycompany.migracionjavafx.Entidades.TUnico;
import com.mycompany.migracionjavafx.Entidades.Tecnico;
import com.mycompany.migracionjavafx.Logica.LogicaEmpleado;
import com.mycompany.migracionjavafx.Logica.LogicaServicio;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class CrearTecnicoController implements Initializable {

    @FXML
    private Button btnCancelar;

    @FXML
    private Button btnRegistrar;

    @FXML
    private CheckBox checkAlineación;

    @FXML
    private CheckBox checkBalanceo;

    @FXML
    private CheckBox checkCalibrar;

    @FXML
    private CheckBox checkSincronizacion;

    @FXML
    private DatePicker dpFecha;

    @FXML
    private TextField txtApellidos;

    @FXML
    private TextField txtCedula;

    @FXML
    private TextField txtNombres;

    private LogicaServicio logicaServicio;
    private LogicaEmpleado logicaTecnico;

    public CrearTecnicoController() {
        this.logicaServicio = new LogicaServicio();
        this.logicaTecnico = new LogicaEmpleado();
    }

    @FXML
    private void clickRegistrar() {
        TUnico tecnico;
        String nombre = this.txtNombres.getText();
        String apellido = this.txtApellidos.getText();
        String cedula = this.txtCedula.getText();
        LocalDate fechaIngreso = this.dpFecha.getValue();
        String sincronizacion = "";
        String especialidad = "";
        if (this.checkSincronizacion.isSelected()) {
            sincronizacion = "Sincronización";
            especialidad = "Sincronizador";
        }
        String balanceo = "";
        String alineacion = "";
        if (this.checkBalanceo.isSelected() && this.checkAlineación.isSelected()) {
            balanceo = "Balanceo";
            alineacion = "Alineación";
            especialidad = "Alineador";
        }
        String calibrar = "";
        if (this.checkCalibrar.isSelected()) {
            calibrar = "Calibrar Válvulas";
            especialidad = "Calibrador";
        }
        ArrayList<String> nomServi = new ArrayList();
        nomServi.add(balanceo);
        nomServi.add(alineacion);
        nomServi.add(sincronizacion);
        nomServi.add(calibrar);

        ArrayList<Servicio> servicios = new ArrayList();
        for (Servicio s : this.logicaServicio.consultarServicios()) {
            for (String ns : nomServi) {
                if (s.getNombreServicio().equals(ns)) {
                    servicios.add(s);
                }
            }
        }
        if (servicios.size() == 1) {
            Servicio sTecn = null;
            for (Servicio ser : servicios) {
                sTecn = ser;
            }
            tecnico = new TUnico("Tecnico monoServicio", sTecn, nombre, apellido, cedula, fechaIngreso, especialidad);
            this.logicaTecnico.registrarEmpleado(tecnico);
            Mensaje.notificarMensaje("Registro exitoso", "El empleado ha sido registrado con exito", Alert.AlertType.INFORMATION);
            this.limpiarComponentes();
        } else {
            TMultiservicio tecnicoM = new TMultiservicio("Tecnico Multiservicio", nombre, apellido, cedula, fechaIngreso, especialidad);
            tecnicoM.setOficios(servicios);
            this.logicaTecnico.registrarEmpleado(tecnicoM);
            Mensaje.notificarMensaje("Registro exitoso", "El empleado ha sido registrado con exito", Alert.AlertType.INFORMATION);
            this.limpiarComponentes();
        }
    }

    @FXML
    private void clickCancelar() {
        this.limpiarComponentes();

    }

    public void limpiarComponentes() {
        this.txtNombres.setText(null);
        this.txtApellidos.setText(null);
        this.txtCedula.setText(null);
        this.dpFecha.setValue(null);

    }

    @FXML
    void clickBalanceo(ActionEvent event) {
        if (this.checkBalanceo.isSelected()) {
            this.checkSincronizacion.setDisable(true);
            this.checkCalibrar.setDisable(true);
            this.checkAlineación.setSelected(true);
            Mensaje.notificarMensaje("Tecnico multiservicio", "Seleccione tambien alineación", Alert.AlertType.INFORMATION);
        }else{
            this.checkSincronizacion.setDisable(false);
            this.checkCalibrar.setDisable(false);
        }
    }

    @FXML
    void clickAlineacion(ActionEvent event) {
        if (this.checkAlineación.isSelected()) {
            this.checkSincronizacion.setDisable(true);
            this.checkCalibrar.setDisable(true);
            this.checkBalanceo.setSelected(true);
            Mensaje.notificarMensaje("Tecnico multiservicio", "Seleccione tambien balanceo", Alert.AlertType.INFORMATION);
        }else{
            this.checkSincronizacion.setDisable(false);
            this.checkCalibrar.setDisable(false);
        }
    }

    @FXML
    void clickCalibrar(ActionEvent event) {
        if (this.checkCalibrar.isSelected()) {
            this.checkSincronizacion.setDisable(true);
            this.checkBalanceo.setDisable(true);
            this.checkAlineación.setDisable(true);
        } else {
            this.checkSincronizacion.setDisable(false);
            this.checkBalanceo.setDisable(false);
            this.checkAlineación.setDisable(false);
        }
    }

    @FXML
    void clickCancelar(ActionEvent event) {
        this.limpiarComponentes();
    }

    @FXML
    void clickSincronizacion(ActionEvent event) {
        if (this.checkSincronizacion.isSelected()) {
            this.checkBalanceo.setDisable(true);
            this.checkAlineación.setDisable(true);
            this.checkCalibrar.setDisable(true);
        } else {
            this.checkBalanceo.setDisable(false);
            this.checkAlineación.setDisable(false);
            this.checkCalibrar.setDisable(false);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.checkBalanceo.setDisable(false);
        this.checkAlineación.setDisable(false);
        this.checkCalibrar.setDisable(false);
        this.checkSincronizacion.setDisable(false);
    }

}
