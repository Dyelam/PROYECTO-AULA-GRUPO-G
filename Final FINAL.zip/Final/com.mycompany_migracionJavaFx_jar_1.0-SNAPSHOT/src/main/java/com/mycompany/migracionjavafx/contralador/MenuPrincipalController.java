/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.migracionjavafx.contralador;

import com.mycompany.migracionjavafx.App;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class MenuPrincipalController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Button btnFactura;
     @FXML
    private Button btnTecnico;
      @FXML
    private Button btnServicio;
       @FXML
    private Button btnNomina;
    @FXML
    private Button btnSalir;
   
    @FXML
    public void clickFactura() throws IOException{
         App.newStage("MenuFactura", true,1240, 720);
    }
     @FXML
    public void clickTecnico() throws IOException{
        App.newStage("MenuTecnico", true,1240, 720);
    }
     @FXML
    public void clickServicio() throws IOException{
         App.newStage("MenuServicios", true,1240, 720);
    }
     @FXML
    public void clickNomina() throws IOException{
         App.newStage("NominaEmpleado", true,1240, 720);
    }
    @FXML
    public void clickSalir(){
      System.exit(0);
    }


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
