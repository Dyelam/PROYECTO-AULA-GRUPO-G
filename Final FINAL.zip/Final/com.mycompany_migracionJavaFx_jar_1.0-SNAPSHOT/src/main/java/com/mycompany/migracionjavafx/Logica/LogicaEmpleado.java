package com.mycompany.migracionjavafx.Logica;


import com.mycompany.migracionjavafx.Entidades.*;
import com.mycompany.migracionjavafx.Persistencia.*;
import java.time.LocalDate;
import java.util.ArrayList;


public class LogicaEmpleado {
    
    private IListaTecnico dato2;
    private LogicaServicio logicaServicio=new LogicaServicio();

    public LogicaEmpleado() {
        //this.dato2= new ListaTecnico();
        this.dato2=new ArchivoObjetoTecnico();
    }
    public void pruebaEmpleado(){
     LocalDate fecha = LocalDate.now();
    Servicio servicio1 = new Balanceo("hhsgs", 0.3, 7, 15);
    Servicio servicio2 = new Sincronizacion("hjshsh", 0.4, 120, 150, 180);
    Servicio servicio3 = new Alineacion("hsgge", 0.3, 30, 25);
    Tecnico tecnico1 = new TUnico("Tecnico monoServicio", servicio2, "Jose", "Vidal", "1044", fecha, "Sincronizador");
    TMultiservicio tecnico2 = new TMultiservicio("Tecnico Multiservicio", "Juan", "Taborda", "1066", fecha, "Alineador");
        this.logicaServicio.registrarServicio(servicio1);
        this.logicaServicio.registrarServicio(servicio2);
        this.logicaServicio.registrarServicio(servicio3);
        servicio1.setCodigo("1");
        servicio2.setCodigo("2");
        servicio3.setCodigo("3");

        this.registrarEmpleado(tecnico1);
        tecnico2.addServicio(servicio1);
        tecnico2.addServicio(servicio3);
        Tecnico tecnico = tecnico2;
        this.registrarEmpleado(tecnico);
    }
    public void registrarEmpleado(Tecnico t){
        this.dato2.addTecnico(t);
    }
    
    public ArrayList<Tecnico> consultarTecnico(){
        return this.dato2.obbTecnico();
    }
    
    public Tecnico buscarTecnico(String cedula){
        Tecnico t = this.dato2.buscarTecnico(cedula);
        return t;
    }
    public void eliminarTecnico(String cedula){
        this.dato2.eliminarTecnico(cedula);
    }
}
