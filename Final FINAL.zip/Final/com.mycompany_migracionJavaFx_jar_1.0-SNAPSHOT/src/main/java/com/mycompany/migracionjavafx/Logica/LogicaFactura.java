package com.mycompany.migracionjavafx.Logica;

import com.mycompany.migracionjavafx.Entidades.*;
import com.mycompany.migracionjavafx.Persistencia.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class LogicaFactura {

    private IListaFactura dato;

    public LogicaFactura() {
        this.dato = new ArchivoObjetoFactura();
    }

    public void registrarFactura(Factura f) {
        this.dato.adicionarFactura(f);
    }

    public ArrayList<Factura> consultarFacturas() {
        return this.dato.obtenerfacturas();
    }

    public Factura crearFactura(String nomCliente, LocalDate fecha, String tVehiculo, String placa, String marca, String modelo, int noCilindro, int tamRing, Tecnico tech, Servicio servicio) {
        Factura nuevaFactura;
        if (nomCliente.isEmpty()) {
            throw new IllegalArgumentException("Se requiere un nombre del cliente");
        }
        if (fecha == null) {
            throw new IllegalArgumentException("Se requiere una fecha de factura");
        }
        if (tVehiculo.isEmpty()) {
            throw new IllegalArgumentException("Se requiere un tipo de vehiculo");

        }
        if (placa.isEmpty()) {
            throw new IllegalArgumentException("Se requiere una placa");

        }
        if (marca.isEmpty()) {
            throw new IllegalArgumentException("Se requiere una marca");

        }
        if (modelo.isEmpty()) {
            throw new IllegalArgumentException("Se requiere un modelo");

        }
        if (noCilindro == 0) {
            throw new IllegalArgumentException("Se requiere un numero de cilindros");
        }
        if (tamRing == 0) {
            throw new IllegalArgumentException("Se requiere un tamaño de ring");

        }
        if (tech == null) {
            throw new IllegalArgumentException("Se requiere un tecnico");

        }
        if (servicio == null) {
            throw new IllegalArgumentException("Se requiere un servicio");

        }
        nuevaFactura= new Factura(nomCliente, fecha, tVehiculo, placa, marca, modelo, noCilindro, tamRing, tech, servicio);
        return nuevaFactura;
    }

    public Factura crearFactura(String nomCliente, LocalDate fecha, String tVehiculo, String placa, String marca, String modelo, int noCilindro, int tamRing, Tecnico tech, ArrayList<Servicio> servicios) {
        Factura nuevaFactura;
        if (nomCliente.isEmpty()) {
            throw new IllegalArgumentException("Se requiere un nombre del cliente");
        }
        if (fecha == null) {
            throw new IllegalArgumentException("Se requiere una fecha de factura");
        }
        if (tVehiculo.isEmpty()) {
            throw new IllegalArgumentException("Se requiere un tipo de vehiculo");

        }
        if (placa.isEmpty()) {
            throw new IllegalArgumentException("Se requiere una placa");

        }
        if (marca.isEmpty()) {
            throw new IllegalArgumentException("Se requiere una marca");

        }
        if (modelo.isEmpty()) {
            throw new IllegalArgumentException("Se requiere un modelo");

        }
        if (noCilindro == 0) {
            throw new IllegalArgumentException("Se requiere un numero de cilindros");
        }
        if (tamRing == 0) {
            throw new IllegalArgumentException("Se requiere un tamaño de ring");

        }
        if (tech == null) {
            throw new IllegalArgumentException("Se requiere un tecnico");

        }
        if (servicios == null) {
            throw new IllegalArgumentException("Se requieren servicios");

        }
       nuevaFactura=new Factura(nomCliente, fecha, tVehiculo, placa, marca, modelo, noCilindro, tamRing, tech, servicios);
       return nuevaFactura;
    }

    public Factura crearFactura(String nomCliente, LocalDate fecha, String tVehiculo, String placa, String marca, String modelo, int noCilindro, int tamRing, ArrayList<Tecnico> tecnicos, ArrayList<Servicio> servicios) {
         Factura nuevaFactura;
        if (nomCliente.isEmpty()) {
            throw new IllegalArgumentException("Se requiere un nombre del cliente");
        }
        if (fecha == null) {
            throw new IllegalArgumentException("Se requiere una fecha de factura");
        }
        if (tVehiculo.isEmpty()) {
            throw new IllegalArgumentException("Se requiere un tipo de vehiculo");

        }
        if (placa.isEmpty()) {
            throw new IllegalArgumentException("Se requiere una placa");

        }
        if (marca.isEmpty()) {
            throw new IllegalArgumentException("Se requiere una marca");

        }
        if (modelo.isEmpty()) {
            throw new IllegalArgumentException("Se requiere un modelo");

        }
        if (noCilindro == 0) {
            throw new IllegalArgumentException("Se requiere un numero de cilindros");
        }
        if (tamRing == 0) {
            throw new IllegalArgumentException("Se requiere un tamaño de ring");

        }
        if (tecnicos == null) {
            throw new IllegalArgumentException("Se requiere un tecnico");

        }
        if (servicios == null) {
            throw new IllegalArgumentException("Se requieren servicios");

        }
        nuevaFactura=new Factura(nomCliente, fecha, tVehiculo, placa, marca, modelo, noCilindro, tamRing, tecnicos, servicios);
        return nuevaFactura;
    }

    public Factura buscarFactura(int noFactura) {
        Factura f = this.dato.buscarFactura(noFactura);
        return f;
    }

    public void eliminarFactura(int noFactura) {
        this.dato.eliminarFactura(noFactura);
    }
}
