/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.migracionjavafx.contralador;

import com.mycompany.migracionjavafx.App;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author EQUIPO
 */
public class MenuFacturaController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Button btnNuevaFactura;
    @FXML
    private Button btnConsultarFactura;
    @FXML
    private Button btnModificarFactura;
    @FXML
    private Button btnEliminarFactura;
    @FXML
    private Button btnListaFactura;
    @FXML
    private StackPane panelOpciones;

    @FXML
    private void clickNuevaFactura() throws IOException {
        this.panelOpciones.getChildren().clear();
        StackPane pane = new StackPane(App.loadFXML("CrearFactura"));
        this.panelOpciones.getChildren().add(pane);
    }

    @FXML
    private void clickConsultarFactura() throws IOException {
        this.panelOpciones.getChildren().clear();
        StackPane pane = new StackPane(App.loadFXML("ConsultarFactura"));
        this.panelOpciones.getChildren().add(pane);
    }

    @FXML
    private void clickModificarFactura() throws IOException {
// this.panelOpciones.getChildren().clear();
//        StackPane pane = new StackPane(App.loadFXML("CrearFactura"));
//        this.panelOpciones.getChildren().add(pane);
    }

    @FXML
    private void clickEliminarFactura() throws IOException {
// this.panelOpciones.getChildren().clear();
//        StackPane pane = new StackPane(App.loadFXML("CrearFactura"));
//        this.panelOpciones.getChildren().add(pane);
    }

    @FXML
    private void clickListaFactura() throws IOException {
        this.panelOpciones.getChildren().clear();
        StackPane pane = new StackPane(App.loadFXML("ListadoFactura"));
        this.panelOpciones.getChildren().add(pane);
    }

    @FXML
    private void clickMenuPrincipal() throws IOException {
        App.newStage("MenuPrincipal", true, 1240, 720);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
