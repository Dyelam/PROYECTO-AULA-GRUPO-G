
package com.mycompany.migracionjavafx.Persistencia;

import com.mycompany.migracionjavafx.Entidades.Servicio;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class ArchivoObjetoServicio implements IListaServicio{
    
    private File archivo;
    private FileOutputStream archivoEscritura;
    private FileInputStream archivoLectura;

    public ArchivoObjetoServicio(String fileName) {
        this.archivo = new File(fileName);        
    }

    public ArchivoObjetoServicio() {
        this("Servicios.txt");
    }
    
    
    @Override
    public void adicionarServicio(Servicio s) {
        ListaServicio list = this.leer();
        list.adicionarServicio(s);
        this.guardar(list);
        
    }

    @Override
    public ArrayList<Servicio> obtenerServicios() {
        ListaServicio list = this.leer();
        return list.obtenerServicios();
    }

    @Override
    public Servicio buscarServicio(String codigo) {
        ListaServicio listSer=this.leer();
        return listSer.buscarServicio(codigo);
    }

    @Override
    public void borrarServicio(String codigo) {
        ListaServicio listSer=this.leer();
        listSer.borrarServicio(codigo);
        this.guardar(listSer);
    }
    
    
    private void guardar(ListaServicio list) {
        ObjectOutputStream oos = null;
        try {
            this.archivoEscritura = new FileOutputStream(this.archivo, false);
            oos = new ObjectOutputStream(this.archivoEscritura);
            oos.writeObject(list);
            oos.close();

        } catch (IOException ioe) {
            throw new IllegalStateException("Error al abrir archivo escritura o el archivo no existe");

        } finally {
            if (this.archivoEscritura != null) {
                try {
                    this.archivoEscritura.close();
                } catch (IOException ioe) {
                    throw new IllegalStateException("Error al cerrar archivo");
                }
            }
        }

    }

    private ListaServicio leer() {
        if (!this.archivo.exists()) {
            return new ListaServicio();
        }

        ObjectInputStream ois = null;
        try {
            this.archivoLectura = new FileInputStream(this.archivo);
            ois = new ObjectInputStream(this.archivoLectura);
            ListaServicio lista = (ListaServicio) ois.readObject();
            return lista;

        } catch (FileNotFoundException fne) {
            throw new IllegalStateException("Error al abrir archivo para lectura");
        } catch (IOException ioe) {
            throw new IllegalStateException("Error al leer archivo");
        } catch (ClassNotFoundException cnf) {
            throw new IllegalStateException("Error al leer la lista de facturas");
        } finally {
            if (this.archivoLectura != null) {
                try {
                    this.archivoLectura.close();
                } catch (IOException ioe) {
                    throw new IllegalStateException("Error al cerrar archivo");
                }
            }
        }

    }
    
}
