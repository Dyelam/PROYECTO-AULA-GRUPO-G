/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.migracionjavafx.Persistencia;

/**
 *
 * @author EQUIPO
 */
public class PersistenciaListServicio {
   private static IListaServicio data2;
    
    private PersistenciaListServicio(){
        data2 = new ListaServicio();
    }
    
    public static IListaServicio get(){
        if(data2==null){
            new PersistenciaListServicio();
        }
        
        return data2;
    }
} 

