/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.migracionjavafx.Logica;

import com.mycompany.migracionjavafx.Entidades.Login;

/**
 *
 * @author EQUIPO
 */
public class LogicaLogin {
    
    private static Login usuario= new Login();
    private static Login usuarioLogeado;
    
    public static void validarLogin(String password){
            
        if( usuario.getContraseña().equals(password)){
            usuarioLogeado = usuario;
        }
        else{
            usuarioLogeado = null;
        }
        
    }
    
    public static void setUsuarioLogeado(Login usuario){
        usuarioLogeado=usuario;
    }
    
    public static Login getUsuarioLogeado(){
        return usuarioLogeado;
    }
    
}

