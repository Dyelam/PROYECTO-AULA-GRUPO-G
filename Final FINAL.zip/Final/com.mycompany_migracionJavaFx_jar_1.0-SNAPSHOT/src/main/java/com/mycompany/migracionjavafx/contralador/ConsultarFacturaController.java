package com.mycompany.migracionjavafx.contralador;

import VistasEntidades.Dialogo;
import com.mycompany.migracionjavafx.Entidades.Factura;
import com.mycompany.migracionjavafx.Entidades.Servicio;
import com.mycompany.migracionjavafx.Entidades.Tecnico;
import com.mycompany.migracionjavafx.Logica.LogicaEmpleado;
import com.mycompany.migracionjavafx.Logica.LogicaFactura;
import com.mycompany.migracionjavafx.Logica.LogicaServicio;
import VistasEntidades.Mensaje;
import VistasEntidades.ServicioVista;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class ConsultarFacturaController implements Initializable {

    @FXML
    private TextField txtNoFactura;
    @FXML
    private Button btnBuscar;
    @FXML
    private Label lbFecha, lbNoFactura, lbNC, lbVehiculo, lbPlaca, lbMarca, lbModelo, lbNCilindros, lbTRing, lbNCT, lbOficio,lbServicios,lbServi,lbTotal,lbVU,lbValorUnitario;

  
   
    private LogicaFactura logicaFactura;
    private LogicaEmpleado logicaTecnico;
    private LogicaServicio logicaServicio;

    public ConsultarFacturaController() {
        this.logicaFactura = new LogicaFactura();
        this.logicaServicio = new LogicaServicio();
        this.logicaTecnico = new LogicaEmpleado();
    }
    int noFactura = 0;

    @FXML
    private void clickBuscar() {

        try {
            noFactura = Integer.parseInt(this.txtNoFactura.getText());
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Dato invalido");
            alert.setHeaderText(null);
            alert.setContentText("Se requiere un valor numerico entero");
            alert.initOwner(null);
            alert.showAndWait();
        }
        System.out.println(noFactura);
        Factura factura = this.logicaFactura.buscarFactura(noFactura);
        if (factura == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Factura no encontrada");
            alert.setHeaderText(null);
            alert.setContentText("No existen coincidencias,intente nuevamente");
            alert.initOwner(null);
            alert.showAndWait();
        } else {
            activarFactura();
            this.lbFecha.setText(factura.getFecha().toString());
            this.lbNoFactura.setText(String.valueOf(factura.getConsecutivo()));
            this.lbNC.setText(factura.getNomCliente());
            this.lbVehiculo.setText(factura.gettVehiculo());
            this.lbPlaca.setText(factura.getAuto().getPlaca());
            this.lbMarca.setText(factura.getAuto().getMarca());
            this.lbModelo.setText(factura.getAuto().getModelo());
            this.lbNCilindros.setText(Integer.toString(factura.getAuto().getNoCilindro()));
            this.lbTRing.setText(Integer.toString(factura.getAuto().getTamRing()));
            if (factura.getTecnicos() != null) {
                String nombresTecnicos = "";
                for (Tecnico t : factura.getTecnicos()) {
                    nombresTecnicos = nombresTecnicos + " " + t.getNombre() + " " + t.getApellido() + "\n";
                }
                this.lbNCT.setText(nombresTecnicos);
            } else {
                this.lbNCT.setText(factura.getTech().getNombre() + " " + factura.getTech().getApellido());
            }
            if(factura.getServicios()!=null){
                String servicios="";
                String valorUnitario="";
                for(Servicio s: factura.getServicios()){
                    servicios=servicios+" "+s.getNombreServicio()+" ";
                    valorUnitario=valorUnitario+" "+s.getCosto()+"  ";
                }
                this.lbServicios.setText(servicios);
                this.lbVU.setText(valorUnitario);
            }else{
                this.lbServicios.setText(factura.getServicio().getNombreServicio());
                this.lbVU.setText(Double.toString(factura.getServicio().getCosto()));
            }
            this.lbTotal.setText(Double.toString(factura.getPrecio()));
            

        }

    }

    @FXML
    private void clickEliminar() {
        if (noFactura == 0) {
            Mensaje.notificarMensaje("Falta de datos", "Falta intoducir el número de la factura", Alert.AlertType.INFORMATION);
        } else {
            ButtonType confirmacion = Dialogo.Dialogo("Confirmar", "¿Estás seguro de eliminar la factura?");
            if (confirmacion.getText().equals("Sí")) {
                System.out.println(noFactura);
                this.logicaFactura.eliminarFactura(noFactura);
                Mensaje.notificarMensaje("Confimacion de eliminado", "Eliminado con exito", Alert.AlertType.INFORMATION);
            }
        }

    }

    @FXML
    private void clickCancelar() {

    }

    public void activarFactura() {
        this.lbFecha.setDisable(false);
        this.lbFecha.setVisible(true);

        this.lbNoFactura.setDisable(false);
        this.lbNoFactura.setVisible(true);

        this.lbNC.setDisable(false);
        this.lbNC.setVisible(true);

        this.lbVehiculo.setDisable(false);
        this.lbVehiculo.setVisible(true);

        this.lbPlaca.setDisable(false);
        this.lbPlaca.setVisible(true);

        this.lbMarca.setDisable(false);
        this.lbMarca.setVisible(true);

        this.lbModelo.setDisable(false);
        this.lbModelo.setVisible(true);

        this.lbNCilindros.setDisable(false);
        this.lbNCilindros.setVisible(true);

        this.lbTRing.setDisable(false);
        this.lbTRing.setVisible(true);

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        this.lbFecha.setDisable(true);
        this.lbFecha.setVisible(false);

        this.lbNoFactura.setDisable(true);
        this.lbNoFactura.setVisible(false);

        this.lbNC.setDisable(true);
        this.lbNC.setVisible(false);

        this.lbVehiculo.setDisable(true);
        this.lbVehiculo.setVisible(false);

        this.lbPlaca.setDisable(true);
        this.lbPlaca.setVisible(false);

        this.lbMarca.setDisable(true);
        this.lbMarca.setVisible(false);

        this.lbModelo.setDisable(true);
        this.lbModelo.setVisible(false);

        this.lbNCilindros.setDisable(true);
        this.lbNCilindros.setVisible(false);

        this.lbTRing.setDisable(true);
        this.lbTRing.setVisible(false);

    }

  

}
