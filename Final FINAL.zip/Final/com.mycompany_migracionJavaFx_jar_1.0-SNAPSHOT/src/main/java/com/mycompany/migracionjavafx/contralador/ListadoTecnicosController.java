
package com.mycompany.migracionjavafx.contralador;

import VistasEntidades.TecnicoVista;
import com.mycompany.migracionjavafx.Entidades.Tecnico;
import com.mycompany.migracionjavafx.Logica.LogicaEmpleado;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class ListadoTecnicosController implements Initializable {

    @FXML
    private TableColumn columnApellido;

    @FXML
    private TableColumn columnCedula;

    @FXML
    private TableColumn columnCodServicio;

    @FXML
    private TableColumn columnEspecialidad;

    @FXML
    private TableColumn columnFechaIngreso;

    @FXML
    private TableColumn columnNombre;

    @FXML
    private TableView<TecnicoVista> tablaTecnicos;

    private ObservableList<TecnicoVista> data3;
    private LogicaEmpleado logc2 = new LogicaEmpleado();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.columnFechaIngreso.setCellValueFactory(new PropertyValueFactory("fechaIngreso"));
        this.columnNombre.setCellValueFactory(new PropertyValueFactory("nombre"));
        this.columnApellido.setCellValueFactory(new PropertyValueFactory("apellido"));
        this.columnCedula.setCellValueFactory(new PropertyValueFactory("cedula"));
        this.columnCodServicio.setCellValueFactory(new PropertyValueFactory("servicio"));
        this.columnEspecialidad.setCellValueFactory(new PropertyValueFactory("especialidad"));
        this.data3 = FXCollections.observableArrayList();
        this.leerTablaTecnicos();
    }

    private void leerTablaTecnicos() {
        ArrayList<Tecnico> listaTecnicos = this.logc2.consultarTecnico();
        this.data3.clear();
        for (Tecnico t : listaTecnicos) {
            TecnicoVista mostrar = new TecnicoVista(t);
            this.data3.add(mostrar);
        }
        this.tablaTecnicos.setItems(this.data3);
    }

}
