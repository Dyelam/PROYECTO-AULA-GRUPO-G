
package com.mycompany.migracionjavafx.Persistencia;

import com.mycompany.migracionjavafx.Entidades.Tecnico;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author USER
 */
public class ArchivoObjetoTecnico implements IListaTecnico{
    
    private File archivo;
    private FileOutputStream archivoEscritura;
    private FileInputStream archivoLectura;

    public ArchivoObjetoTecnico(String filename) {
        this.archivo = new File(filename);
    }

    public ArchivoObjetoTecnico() {
        this("Tecnicos.obj");
    }
    
    
    @Override
    public void addTecnico(Tecnico t) {
        ListaTecnico lista = this.leer();
        lista.addTecnico(t);
        this.guardar(lista);
    }

    @Override
    public ArrayList<Tecnico> obbTecnico() {
         ListaTecnico lista = this.leer();
        return lista.obbTecnico();

    }

    @Override
    public Tecnico buscarTecnico(String cedula) {
        ListaTecnico listTec=this.leer();
        return listTec.buscarTecnico(cedula);
    }

    @Override
    public void eliminarTecnico(String cedula) {
        ListaTecnico listTec=this.leer();
        listTec.eliminarTecnico(cedula);
        this.guardar(listTec);
    }
    
    private void guardar(ListaTecnico lista) {
        ObjectOutputStream oos = null;
        try {
            this.archivoEscritura = new FileOutputStream(this.archivo, false);
            oos = new ObjectOutputStream(this.archivoEscritura);
            oos.writeObject(lista);
            oos.close();

        } catch (IOException ioe) {
            throw new IllegalStateException("Error al abrir archivo escritura o el archivo no existe");

        } finally {
            if (this.archivoEscritura != null) {
                try {
                    this.archivoEscritura.close();
                } catch (IOException ioe) {
                    throw new IllegalStateException("Error al cerrar archivo");
                }
            }
        }

    }

    private ListaTecnico leer() {
        if (!this.archivo.exists()) {
            return new ListaTecnico();
        }

        ObjectInputStream ois = null;
        try {
            this.archivoLectura = new FileInputStream(this.archivo);
            ois = new ObjectInputStream(this.archivoLectura);
            ListaTecnico lista = (ListaTecnico) ois.readObject();
            return lista;

        } catch (FileNotFoundException fne) {
            throw new IllegalStateException("Error al abrir archivo para elctura");
        } catch (IOException ioe) {
            throw new IllegalStateException("Error al leer archivo");
        } catch (ClassNotFoundException cnf) {
            throw new IllegalStateException("Error al leer la lista de facturas");
        } finally {
            if (this.archivoLectura != null) {
                try {
                    this.archivoLectura.close();
                } catch (IOException ioe) {
                    throw new IllegalStateException("Error al cerrar archivo");
                }
            }
        }

    }
    
}
