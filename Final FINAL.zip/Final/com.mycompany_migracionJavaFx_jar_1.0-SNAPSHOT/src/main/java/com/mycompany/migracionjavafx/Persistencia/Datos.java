/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.migracionjavafx.Persistencia;

import com.mycompany.migracionjavafx.Entidades.Alineacion;
import com.mycompany.migracionjavafx.Entidades.Balanceo;
import com.mycompany.migracionjavafx.Entidades.Servicio;
import com.mycompany.migracionjavafx.Entidades.Sincronizacion;
import com.mycompany.migracionjavafx.Entidades.TMultiservicio;
import com.mycompany.migracionjavafx.Entidades.TUnico;
import com.mycompany.migracionjavafx.Entidades.Tecnico;
import com.mycompany.migracionjavafx.Logica.LogicaEmpleado;
import com.mycompany.migracionjavafx.Logica.LogicaServicio;
import java.time.LocalDate;

/**
 *
 * @author EQUIPO
 */
public  class Datos {
    private LogicaEmpleado logicaTecnico;
    private LogicaServicio logicaServicio;
    LocalDate fecha = LocalDate.now();
    Servicio servicio1 = new Balanceo("hhsgs", 0.3, 7, 15);
    Servicio servicio2 = new Sincronizacion("hjshsh", 0.4, 120, 150, 180);
    Servicio servicio3 = new Alineacion("hsgge", 0.3, 30, 25);
    Tecnico tecnico1 = new TUnico("Tecnico monoServicio", servicio2, "Jose", "Vidal", "1044", fecha, "Sincronizador");
    TMultiservicio tecnico2 = new TMultiservicio("Tecnico Multiservicio", "Juan", "Taborda", "1066", fecha, "Alineador");
    public Datos(){
       this.logicaServicio=new LogicaServicio();
       this.logicaTecnico=new LogicaEmpleado();
     }

    public void Registro() {
        this.logicaServicio.registrarServicio(servicio1);
        this.logicaServicio.registrarServicio(servicio2);
        this.logicaServicio.registrarServicio(servicio3);
        servicio1.setCodigo("1");
        servicio2.setCodigo("2");
        servicio3.setCodigo("3");

        this.logicaTecnico.registrarEmpleado(tecnico1);
        tecnico2.addServicio(servicio1);
        tecnico2.addServicio(servicio3);
        Tecnico tecnico = tecnico2;
        this.logicaTecnico.registrarEmpleado(tecnico);
    }
}
