/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.migracionjavafx.contralador;

import VistasEntidades.FacturaVista;
import VistasEntidades.NominaVista;
import com.mycompany.migracionjavafx.App;
import com.mycompany.migracionjavafx.Entidades.Factura;
import com.mycompany.migracionjavafx.Entidades.Nomina;
import com.mycompany.migracionjavafx.Entidades.Tecnico;
import com.mycompany.migracionjavafx.Logica.LogicaEmpleado;
import com.mycompany.migracionjavafx.Logica.LogicaFactura;
import VistasEntidades.Mensaje;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author EQUIPO
 */
public class NominaEmpleadoController implements Initializable {

    @FXML
    private TextField txtCedula;
    @FXML
    private Button btnBuscar;
    @FXML
    private TableView<NominaVista> tableTrabajo;
    @FXML
    private TableColumn columnFecha;
    @FXML
    private TableColumn columNoFactura;
    @FXML
    private TableColumn columnNombreServicio;
    @FXML
    private TableColumn columnPago;
    @FXML
    private TableColumn columnValor;
    @FXML
    private Label lbNombres;
    @FXML
    private Label lbNombre;
    @FXML
    private Label lbCc;
    @FXML
    private Label lbCedula;
    @FXML
    private Label lbFIngreso;
    @FXML
    private Label lbFecha;
    @FXML
    private Label lbFIngreso1;
    @FXML
    private Label lbFecha1;
    @FXML
    private Label lbFIngreso11;
    @FXML
    private Label lbEspecialidad;
    @FXML
    private DatePicker dpFechaInicio, dpFechaFinal;
    @FXML
    private Label lbPagoTotal;
    @FXML
    private Button btnMenuPrincipal;

    private Nomina nomina;
    private ObservableList<NominaVista> data;
    private LogicaFactura logica = new LogicaFactura();
    private LogicaEmpleado logicaTecnico = new LogicaEmpleado();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void clickBuscar() {
        String cedula = this.txtCedula.getText();
        Tecnico tecBuscado = this.logicaTecnico.buscarTecnico(cedula);
        if (tecBuscado == null) {
            Mensaje.notificarMensaje("Empleado no encontrado", "No existen coincidencias, intente nuevamente", Alert.AlertType.INFORMATION);
        } else {

            LocalDate fechaInicio = this.dpFechaInicio.getValue();
            LocalDate fechaFinal = this.dpFechaFinal.getValue();
            if (fechaInicio.isBefore(fechaFinal)) {
                ArrayList<Factura> listaFactura = this.logica.consultarFacturas();
                if (listaFactura != null) {
                    nomina = new Nomina(tecBuscado, listaFactura, fechaInicio, fechaFinal);
                    this.lbNombre.setText(tecBuscado.getNombre() + " " + tecBuscado.getApellido());
                    this.lbCedula.setText(tecBuscado.getCedula());
                    this.lbFecha.setText(tecBuscado.getFechaIngreso().toString());
                    nomina.calcularPago();
                    this.lbPagoTotal.setText(Double.toString(nomina.getPago()) + " $");
                    this.lbEspecialidad.setText(tecBuscado.getDetalle());
                } else {
                    Mensaje.notificarMensaje("Datos vacios", "No se encontró facturas creadas", Alert.AlertType.INFORMATION);
                }
                this.columNoFactura.setCellValueFactory(new PropertyValueFactory("noFactura"));
                this.columnFecha.setCellValueFactory(new PropertyValueFactory("fechaFactura"));

                this.columnNombreServicio.setCellValueFactory(new PropertyValueFactory("servicio"));
                this.columnPago.setCellValueFactory(new PropertyValueFactory("porcentaje"));
                this.columnValor.setCellValueFactory(new PropertyValueFactory("valorFactura"));
                this.data = FXCollections.observableArrayList();
                this.mostrarTabla(tecBuscado);
            } else {
                Mensaje.notificarMensaje("Error en las fechas", "La fecha de inicio es superior a la fecha final, intente nuevamente", Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    public void clickMenuPrincipal() throws IOException {
        App.newStage("MenuPrincipal", true, 1240, 720);
    }

    public void mostrarTabla(Tecnico tec) {
        this.data.clear();
        for (Factura f : this.nomina.rangoFacturas()) {
            if (f.getTech() != null) {
                if (f.getTech().getCedula().equals(tec.getCedula())) {
                    NominaVista mostrar = new NominaVista(f);
                    this.data.add(mostrar);
                }
            } else {
                for (Tecnico t : f.getTecnicos()) {
                    if (t.getCedula().equals(tec.getCedula())) {
                        NominaVista mostrar = new NominaVista(f);
                        this.data.add(mostrar);
                    }
                }
            }
        }
        this.tableTrabajo.setItems(this.data);
    }

}
