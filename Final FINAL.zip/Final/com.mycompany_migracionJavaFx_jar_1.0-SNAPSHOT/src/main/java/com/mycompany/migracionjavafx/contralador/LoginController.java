
package com.mycompany.migracionjavafx.contralador;

import com.mycompany.migracionjavafx.App;
import com.mycompany.migracionjavafx.Logica.LogicaLogin;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;


/**
 * FXML Controller class
 *
 * @author USER
 */
public class LoginController implements Initializable {

    /**
     * Initializes the controller class.
     */
   
    @FXML private PasswordField txtPassword;
    @FXML private Button btnLogin, btnCancelar;
    
    @FXML
    public void clickLogin(ActionEvent e) throws IOException{
        String password = this.txtPassword.getText();
        LogicaLogin.validarLogin( password);
        if(LogicaLogin.getUsuarioLogeado()!=null){
            App.newStage("MenuPrincipal", true,1240, 720);
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Login no valido");
            alert.setHeaderText(null);
            alert.setContentText("Contraseña incorrecta, intenete nuevamente");
            alert.initOwner(null);
            alert.showAndWait();
        }
         
    }
    
    @FXML
    public void clickCancelar(ActionEvent e){
         this.txtPassword.setText(null);
         System.exit(0);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
