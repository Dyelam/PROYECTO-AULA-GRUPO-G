
package com.mycompany.migracionjavafx.contralador;



import com.mycompany.migracionjavafx.App;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;


public class MenuTecnicoController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Button btnNuevoTecnico,btnConsultarTecnico,btnDespedirTecnico,btnModificarTecnico,btnListaTecnico;
    @FXML
    private StackPane panelOpciones;
    
    @FXML
    private void clickNuevoTecnico() throws IOException{
        this.panelOpciones.getChildren().clear();
        StackPane pane = new StackPane(App.loadFXML("CrearTecnico"));
        this.panelOpciones.getChildren().add(pane);
    }
    @FXML
    private void clickConsultarTecnico() throws IOException{
         this.panelOpciones.getChildren().clear();
        StackPane pane = new StackPane(App.loadFXML("ConsultarTecnico"));
        this.panelOpciones.getChildren().add(pane);
    }
    @FXML
    private void clickDespedirTecnico(){
        
    }
    @FXML
    private void clickModificarTecnico(){
        
    }
    @FXML
    private void clickListaTecnico() throws IOException{
         this.panelOpciones.getChildren().clear();
        StackPane pane = new StackPane(App.loadFXML("ListadoTecnicos"));
        this.panelOpciones.getChildren().add(pane);
    }
    @FXML
    private void clickMenuPrincipal() throws IOException{
         App.newStage("MenuPrincipal", true,1240, 720);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}