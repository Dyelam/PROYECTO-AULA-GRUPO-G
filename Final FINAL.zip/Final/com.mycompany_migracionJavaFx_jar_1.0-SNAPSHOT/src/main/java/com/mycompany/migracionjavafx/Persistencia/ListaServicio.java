package com.mycompany.migracionjavafx.Persistencia;


import com.mycompany.migracionjavafx.Entidades.Alineacion;
import com.mycompany.migracionjavafx.Entidades.Balanceo;
import com.mycompany.migracionjavafx.Entidades.Servicio;
import com.mycompany.migracionjavafx.Entidades.Sincronizacion;
import java.io.Serializable;
import java.util.ArrayList;

public class ListaServicio implements IListaServicio,Serializable {
    private  ArrayList<Servicio> ListaServicio;
    Servicio servicio1 = new Balanceo("hhsgs", 0.3, 7, 15);
    Servicio servicio2 = new Sincronizacion("hjshsh", 0.4, 120, 150, 180);
    Servicio servicio3 = new Alineacion("hsgge", 0.3, 30, 25);
   
    public ListaServicio() {
        this.ListaServicio = new ArrayList();
    }
    
    @Override
    public void adicionarServicio(Servicio s) {
        this.ListaServicio.add(s);
    }
   
    @Override
    public ArrayList<Servicio> obtenerServicios() {
        ArrayList<Servicio> fact = new ArrayList(this.ListaServicio);
        return fact;
    }

    @Override
    public Servicio buscarServicio(String codigo) {
        Servicio serviBusc = null;
        for(Servicio se: this.ListaServicio){
            if(se.getCodigo().equals(codigo)){
                serviBusc = se;
            }
        }
        return serviBusc;
    }
    @Override
    public void borrarServicio(String codigo){
        Servicio servBorrar=this.buscarServicio(codigo);
        this.ListaServicio.remove(servBorrar);
    }



}
