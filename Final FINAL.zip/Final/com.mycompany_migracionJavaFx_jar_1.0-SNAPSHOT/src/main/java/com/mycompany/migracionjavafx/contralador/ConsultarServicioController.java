package com.mycompany.migracionjavafx.contralador;

import VistasEntidades.Dialogo;
import VistasEntidades.Mensaje;
import com.mycompany.migracionjavafx.Entidades.Alineacion;
import com.mycompany.migracionjavafx.Entidades.Balanceo;
import com.mycompany.migracionjavafx.Entidades.CalibrarValvulas;
import com.mycompany.migracionjavafx.Entidades.Servicio;
import com.mycompany.migracionjavafx.Entidades.Sincronizacion;
import com.mycompany.migracionjavafx.Logica.LogicaEmpleado;
import com.mycompany.migracionjavafx.Logica.LogicaServicio;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;

public class ConsultarServicioController implements Initializable {

    @FXML
    private Label description;
    @FXML
    private Label lbdescripcion;
    @FXML
    private Label tech;
    @FXML
    private Label lbPorcentaje;
    @FXML
    private Label prieceOne;
    @FXML
    private Label lbPrecio1;
    @FXML
    private Label prieceTwo;
    @FXML
    private Label lbPrecio2;
    @FXML
    private Button btnEliminar;
    @FXML
    private Button btnCancelar;
    @FXML
    private CheckBox cbAlineacion;

    @FXML
    private CheckBox cbBalanceo;

    @FXML
    private CheckBox cbCalibrar;

    @FXML
    private CheckBox cbSincronizacion;

    private LogicaServicio logicaServicio = new LogicaServicio();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void clickSincronizacion(ActionEvent event) {
        if (this.cbSincronizacion.isSelected()) {
            this.cbAlineacion.setDisable(true);
            this.cbBalanceo.setDisable(true);
            this.cbCalibrar.setDisable(true);
            Servicio servi = null;
            for (Servicio s : this.logicaServicio.consultarServicios()) {
                if (s.getNombreServicio().equals("Sincronización")) {
                    servi = s;
                }
            }
            this.lbdescripcion.setText(servi.getDescripcion());
            this.lbPorcentaje.setText(Integer.toString((int) (100 * servi.getPorcentaje())));
            Sincronizacion sincro = (Sincronizacion) servi;
            this.prieceOne.setText("Precio por número de cilindros [3-4]");
            this.lbPrecio1.setText("$"+Double.toString(sincro.getPrecio1()));
            this.prieceTwo.setText("Precio por número de cilindros[6]");
            this.lbPrecio2.setText("$"+Double.toString(sincro.getPrecio2()));
        } else {
            this.cbAlineacion.setDisable(false);
            this.cbBalanceo.setDisable(false);
            this.cbCalibrar.setDisable(false);
        }

    }

    @FXML
    private void clickBalanceo(ActionEvent event) {
        if (this.cbBalanceo.isSelected()) {
            this.cbAlineacion.setDisable(true);
            this.cbSincronizacion.setDisable(true);
            this.cbCalibrar.setDisable(true);
            Servicio servi = null;
            for (Servicio s : this.logicaServicio.consultarServicios()) {
                if (s.getNombreServicio().equals("Balanceo")) {
                    servi = s;
                }
            }
            this.lbdescripcion.setText(servi.getDescripcion());
            this.lbPorcentaje.setText(Integer.toString((int) (100 * servi.getPorcentaje())));
            Balanceo balanceo = (Balanceo) servi;
            this.prieceOne.setText("Precio por número de ring [13-14]");
            this.lbPrecio1.setText("$"+Double.toString(balanceo.getPrecio1()));
            this.prieceTwo.setText("Precio por número de ring [14-18]");
            this.lbPrecio2.setText("$"+Double.toString(balanceo.getPrecio2()));
        } else {
            this.cbAlineacion.setDisable(false);
            this.cbSincronizacion.setDisable(false);
            this.cbCalibrar.setDisable(false);
        }
    }

    @FXML
    private void clickAlineacion(ActionEvent event) {
        if (this.cbAlineacion.isSelected()) {
            this.cbBalanceo.setDisable(true);
            this.cbSincronizacion.setDisable(true);
            this.cbCalibrar.setDisable(true);
            Servicio alinea = null;
            for (Servicio s : this.logicaServicio.consultarServicios()) {
                if (s.getNombreServicio().equals("Alineación")) {
                    alinea = s;
                }
            }
            this.lbdescripcion.setText(alinea.getDescripcion());
            this.lbPorcentaje.setText(Integer.toString((int) (100 * alinea.getPorcentaje())));
            Alineacion a = (Alineacion) alinea;
            this.prieceOne.setText("Precio por Camioneta");
            this.lbPrecio1.setText("$"+Double.toString(a.getPrecio1()));
            this.prieceTwo.setText("Precio por Automóvil");
            this.lbPrecio2.setText("$"+Double.toString(a.getPrecio2()));

        } else {
            this.cbBalanceo.setDisable(false);
            this.cbSincronizacion.setDisable(false);
            this.cbCalibrar.setDisable(false);
        }
    }

    @FXML
    private void clickCalibrar(ActionEvent event) {
        if (this.cbCalibrar.isSelected()) {
            this.cbBalanceo.setDisable(true);
            this.cbSincronizacion.setDisable(true);
            this.cbAlineacion.setDisable(true);
            Servicio servi = null;
            for (Servicio s : this.logicaServicio.consultarServicios()) {
                if (s.getNombreServicio().equals("Calibrar Válvulas")) {
                    servi = s;
                }
            }
            this.lbdescripcion.setText(servi.getDescripcion());
            this.lbPorcentaje.setText(Integer.toString((int) (100 * servi.getPorcentaje())));
            CalibrarValvulas cva = (CalibrarValvulas) servi;
            this.prieceOne.setText("Precio por número de cilindros [3-4]");
            this.lbPrecio1.setText("$"+Double.toString(cva.getPrecio1()));
            this.prieceTwo.setText("Precio por número de cilindros[6]");
            this.lbPrecio2.setText("$"+Double.toString(cva.getPrecio2()));
        } else {
            this.cbBalanceo.setDisable(false);
            this.cbSincronizacion.setDisable(false);
            this.cbAlineacion.setDisable(true);

        }
    }

    public void eliminar(String nombre) {
        Servicio serv = null;
        for (Servicio s : logicaServicio.consultarServicios()) {
            if (s.getNombreServicio().equals(nombre)) {
                serv = s;
            }
        }
        String codigo = serv.getCodigo();
        this.logicaServicio.borrarServicio(codigo);
    }

    @FXML
    private void clickEliminar(ActionEvent event) {
        ButtonType confirmacion = Dialogo.Dialogo("Confirmar", "¿Estás seguro de eliminar el servicio?");
        if (confirmacion.getText().equals("Sí")) {
            
            if (this.cbAlineacion.isSelected()) {
                this.eliminar("Alineación");
            }
            if (this.cbBalanceo.isSelected()) {
                this.eliminar("Balanceo");
            }
            if (this.cbCalibrar.isSelected()) {
                this.eliminar("Calibrar Vávulas");
            }
            if (this.cbSincronizacion.isSelected()) {
                this.eliminar("Sincronización");
            }
            Mensaje.notificarMensaje("Confimacion de eliminado", "Eliminado con exito", Alert.AlertType.INFORMATION);
        }
    }
    public void limpiarComponentes(){
        
    }

    @FXML
    private void clickCancelar(ActionEvent event) {
        
    }

}
