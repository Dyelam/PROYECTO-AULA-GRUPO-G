
package com.mycompany.migracionjavafx.contralador;

import VistasEntidades.FacturaVista;
import com.mycompany.migracionjavafx.Entidades.Factura;
import com.mycompany.migracionjavafx.Logica.LogicaFactura;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ListadoFacturaController implements Initializable {

    @FXML
    private TableView<FacturaVista> tablaFacturas;
    @FXML
    private TableColumn columnNoFactura, columnFechaFactura, columnNombreCliente, columnPlaca, columnMarca, columnModelo, columnServicio, columnTecnico, columnValor;

    private ObservableList<FacturaVista> data;
    private LogicaFactura logica = new LogicaFactura();

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        this.columnNoFactura.setCellValueFactory(new PropertyValueFactory("noFactura"));
        this.columnFechaFactura.setCellValueFactory(new PropertyValueFactory("fechaFactura"));
        this.columnNombreCliente.setCellValueFactory(new PropertyValueFactory("nombreCliente"));
        this.columnPlaca.setCellValueFactory(new PropertyValueFactory("placa"));
        this.columnMarca.setCellValueFactory(new PropertyValueFactory("marca"));
        this.columnModelo.setCellValueFactory(new PropertyValueFactory("modelo"));
        this.columnServicio.setCellValueFactory(new PropertyValueFactory("servicio"));
        this.columnTecnico.setCellValueFactory(new PropertyValueFactory("tecnico"));
        this.columnValor.setCellValueFactory(new PropertyValueFactory("valorFactura"));
        this.data = FXCollections.observableArrayList();
        this.leerTablaFacturas();
    }

    public void leerTablaFacturas() {
        
        ArrayList<Factura> listaFacturas = this.logica.consultarFacturas();
        this.data.clear();
        for (Factura f : listaFacturas) {
            FacturaVista mostrar = new FacturaVista(f);
            this.data.add(mostrar);
            System.out.println(mostrar);
            f.ImprimirFactura();
        }
        this.tablaFacturas.setItems(this.data);
    }

}
