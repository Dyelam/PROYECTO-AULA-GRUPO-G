package com.mycompany.migracionjavafx.contralador;

import com.mycompany.migracionjavafx.Entidades.Alineacion;
import com.mycompany.migracionjavafx.Entidades.Balanceo;
import com.mycompany.migracionjavafx.Entidades.CalibrarValvulas;
import com.mycompany.migracionjavafx.Entidades.Factura;
import com.mycompany.migracionjavafx.Entidades.Servicio;
import com.mycompany.migracionjavafx.Entidades.Sincronizacion;
import com.mycompany.migracionjavafx.Entidades.TMultiservicio;
import com.mycompany.migracionjavafx.Entidades.TUnico;
import com.mycompany.migracionjavafx.Entidades.Tecnico;
import com.mycompany.migracionjavafx.Logica.LogicaEmpleado;
import com.mycompany.migracionjavafx.Logica.LogicaFactura;
import com.mycompany.migracionjavafx.Logica.LogicaServicio;
import VistasEntidades.Mensaje;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author DIEGO
 */
public class CrearFacturaController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TextField txtNoFactura, txtNombreCliente, txtPlaca, txtMarca, txtModelo;
    @FXML
    private DatePicker dpFecha;
    @FXML
    private ComboBox<String> cmbVehiculo, cmbTecnicos;
    @FXML
    private ComboBox<Integer> cmbNoCilindros, cmbTamañoRing, cmbNumeroLlantas;
    @FXML
    private CheckBox cbAlineacion, cbBalanceo, cbCalibrarValvulas, cbSincronizacion;
    @FXML
    private Button btnRegistrar, btnCancelar;
    private LogicaFactura logicaFactura;
    private LogicaServicio logicaServicio;
    private LogicaEmpleado logicaTecnico;

    private ObservableList<Integer> listNumCil = FXCollections.observableArrayList();
    private ObservableList<Integer> listRing = FXCollections.observableArrayList();
    private ObservableList<Integer> listLlantas = FXCollections.observableArrayList();
    private ObservableList<String> listTVeh = FXCollections.observableArrayList();
    private ObservableList<String> listTec = FXCollections.observableArrayList();

    LocalDate fecha = LocalDate.now();
    Servicio servicio1 = new Balanceo("hhsgs", 0.3, 7, 15);
    Servicio servicio2 = new Sincronizacion("hjshsh", 0.4, 120, 150, 180);
    Servicio servicio3 = new Alineacion("hsgge", 0.3, 30, 25);
    Tecnico tecnico1 = new TUnico("Tecnico monoServicio", servicio2, "Jose", "Vidal", "1044", fecha, "Sincronizador");
    TMultiservicio tecnico2 = new TMultiservicio("Tecnico Multiservicio", "Juan", "Taborda", "1066", fecha, "Alineador");

    public CrearFacturaController() {
        this.logicaFactura = new LogicaFactura();
        this.logicaServicio = new LogicaServicio();
        this.logicaTecnico = new LogicaEmpleado();

    }

    public void Registro() {

        servicio1.setCodigo("1");
        servicio2.setCodigo("2");
        servicio3.setCodigo("3");
        this.logicaServicio.registrarServicio(servicio1);
        this.logicaServicio.registrarServicio(servicio2);
        this.logicaServicio.registrarServicio(servicio3);

        this.logicaTecnico.registrarEmpleado(tecnico1);
        tecnico2.addServicio(servicio1);
        tecnico2.addServicio(servicio3);
        Tecnico tecnico = tecnico2;
        this.logicaTecnico.registrarEmpleado(tecnico);

    }

    @FXML
    private void clickRegistrar() {
        ArrayList<String> nombresServicios = new ArrayList();
        int continuar = 0;
        LocalDate fechaFactura = null;
        String nombreCliente = "";
        String tVehiculo = "";
        String placa = "";
        Factura nuevaFactura;
        String marca = "";
        String modelo = "";
        int noCilindros = 0;
        int tamañoRing = 0;
        String tecnNombre = "";
        int noFactura = 0;
        String svSincronizacion = "";
        String svAlineacion = "";
        String svBalanceo = "";
        String svCalibrarValvulas = "";
        int noLlantas = 0;
        
        
        try {
            noFactura = Integer.parseInt(this.txtNoFactura.getText());
        } catch (NumberFormatException nfe) {
            Mensaje.notificarMensaje("Dato inválido", "Error el número de la factura debe ser numérico entero, intente nuevamente", Alert.AlertType.ERROR);
        } catch (NullPointerException npe) {
            Mensaje.notificarMensaje("Dato no registrado", "Debe digitar un número de factura para continuar", Alert.AlertType.INFORMATION);
        }
        int no = 0;
        for (Factura f : this.logicaFactura.consultarFacturas()) {
            no = f.getConsecutivo();
        }
        if (noFactura <= no) {
            Mensaje.notificarMensaje("Dato inválido", "Error número de factura ya registrado,intente nuevamente", Alert.AlertType.ERROR);
        } else {
            try {
                fechaFactura = this.dpFecha.getValue();
                nombreCliente = this.txtNombreCliente.getText();
                tVehiculo = this.cmbVehiculo.getSelectionModel().getSelectedItem();
                placa = this.txtPlaca.getText();
                marca = this.txtMarca.getText();
                modelo = this.txtModelo.getText();
                noCilindros = this.cmbNoCilindros.getValue();
                tamañoRing = this.cmbTamañoRing.getValue();
                if (this.cbSincronizacion.isSelected()) {
                    svSincronizacion = this.cbSincronizacion.getText();
                    System.out.println(svSincronizacion);
                }

                if (this.cbAlineacion.isSelected()) {
                    svAlineacion = this.cbAlineacion.getText();
                }

                if (this.cbBalanceo.isSelected()) {
                    svBalanceo = this.cbBalanceo.getText();
                }

                if (this.cbCalibrarValvulas.isSelected()) {
                    svCalibrarValvulas = this.cbCalibrarValvulas.getText();
                }

                try {
                    noLlantas = this.cmbNumeroLlantas.getValue();
                } catch (NullPointerException npe) {
                    noLlantas = 0;
                }
                System.out.println("Numero= " + noLlantas);
                String[] nombreTecnico = this.cmbTecnicos.getValue().split("\\s+");
                tecnNombre = nombreTecnico[0];
            } catch (NullPointerException npe) {
                Mensaje.notificarMensaje("Datos por rellenar", "Error existen campos vacios", Alert.AlertType.INFORMATION);
                continuar = 1;
            }
            if (continuar == 0) {
                Tecnico tech = null;
                for (Tecnico tec : this.logicaTecnico.consultarTecnico()) {
                    if (tecnNombre.equals(tec.getNombre())) {
                        tech = tec;
                    }
                }

                nombresServicios.add(svSincronizacion);
                nombresServicios.add(svBalanceo);
                nombresServicios.add(svAlineacion);
                nombresServicios.add(svCalibrarValvulas);

                ArrayList<Servicio> servicios = new ArrayList();
                for (Servicio s : this.logicaServicio.consultarServicios()) {
                    for (String ns : nombresServicios) {
                        if (s.getNombreServicio().equals(ns)) {
                            servicios.add(s);
                        }
                    }
                }
                Servicio servRea = null;
                if (servicios.size() == 1) {

                    for (Servicio se : servicios) {
                        servRea = se;
                    }
                    servicios.clear();
                    nuevaFactura = new Factura(nombreCliente, fechaFactura, tVehiculo, placa, marca, modelo, noCilindros, tamañoRing, tech, servRea);
                    nuevaFactura.setConsecutivo(noFactura);
                    String nombreServicio = servRea.getNombreServicio();

                    //Sincronizacion
                    if (nombreServicio.equals("Sincronización")) {
                        Sincronizacion serv = (Sincronizacion) servRea;
                        serv.calcularCosto(noCilindros);
                        nuevaFactura.calcularCostoUnicoServicio();
                        this.logicaFactura.registrarFactura(nuevaFactura);
                    }

                    //Alineacion
                    if (nombreServicio.equals("Alineación")) {
                        Alineacion serv = (Alineacion) servRea;
                        int tv = 0;
                        if (tVehiculo.equals("Camioneta")) {
                            tv = 1;
                        }
                        serv.calcularCosto(tv);
                        nuevaFactura.calcularCostoUnicoServicio();
                        this.logicaFactura.registrarFactura(nuevaFactura);
                    }

                    //Balanceo 
                    if (nombreServicio.equals("Balanceo")) {
                        Balanceo serv = (Balanceo) servRea;
                        serv.calcularCosto(noLlantas, tamañoRing);
                        nuevaFactura.calcularCostoUnicoServicio();
                        this.logicaFactura.registrarFactura(nuevaFactura);
                    }

                    //Calibrar Valvulas
                    if (nombreServicio.equals("Calibrar Válvulas")) {
                        CalibrarValvulas serv = (CalibrarValvulas) servRea;
                        serv.calcularCosto(noCilindros);
                        nuevaFactura.calcularCostoUnicoServicio();
                        this.logicaFactura.registrarFactura(nuevaFactura);
                    }
                } else {
                    System.out.println("Estoy aca");
                    nuevaFactura = new Factura(nombreCliente, fechaFactura, tVehiculo, placa, marca, modelo, noCilindros, tamañoRing, tech, servicios);
                    nuevaFactura.setConsecutivo(noFactura);
                    for (Servicio s1 : nuevaFactura.getServicios()) {
                        //Sincronizacion
                        System.out.println(s1.toString());
                        if (s1.getNombreServicio().equals("Sincronización")) {
                            Sincronizacion sincro = (Sincronizacion) s1;
                            sincro.calcularCosto(noCilindros);
                        }

                        //Alineacion
                        if (s1.getNombreServicio().equals("Alineación")) {
                            Alineacion alinea = (Alineacion) s1;
                            int tv = 0;
                            if (tVehiculo.equals("Camioneta")) {
                                tv = 1;
                            }
                            alinea.calcularCosto(tv);
                        }

                        //Balanceo 
                        if (s1.getNombreServicio().equals("Balanceo")) {
                            Balanceo balanceo = (Balanceo) s1;
                            balanceo.calcularCosto(noLlantas, tamañoRing);
                        }
                        //Calibrar Valvulas
                        if (s1.getNombreServicio().equals("Calibrar Válvulas")) {
                            CalibrarValvulas calib = (CalibrarValvulas) s1;
                            calib.calcularCosto(noCilindros);
                        }
                    }
                    System.out.println(nuevaFactura.getConsecutivo());
                    nuevaFactura.calcularCostoMultiServicios();
                    this.logicaFactura.registrarFactura(nuevaFactura);
                }
                nuevaFactura.ImprimirFactura();
                Mensaje.notificarMensaje("Registro existoso", "La factura ha sido registrada con exito", Alert.AlertType.INFORMATION);
                this.limpiarComponentes();
            }
        }
    }

    @FXML
    private void clickBalanceo() {
        this.cmbNumeroLlantas.setDisable(!this.cbBalanceo.isSelected());
    }

    @FXML
    private void clickCancelar() {
        this.limpiarComponentes();
    }

    public void limpiarComponentes() {
        this.cmbNumeroLlantas.setDisable(true);
        this.txtPlaca.setText(null);
        this.txtMarca.setText(null);
        this.txtModelo.setText(null);
        this.dpFecha.setValue(null);
        this.txtNoFactura.setText(null);
        this.cmbTecnicos.getItems().clear();
        this.txtNombreCliente.setText(null);
        this.cmbVehiculo.setValue(null);
        this.cmbNoCilindros.setValue(null);
        this.cmbTamañoRing.setValue(null);
        this.cmbNumeroLlantas.setValue(null);
        this.cmbTecnicos.setValue(null);
        this.cbAlineacion.setSelected(false);
        this.cbBalanceo.setSelected(false);
        this.cbCalibrarValvulas.setSelected(false);
        this.cbSincronizacion.setSelected(false);

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        //this.Registro();
        this.cmbNumeroLlantas.setDisable(true);
        this.listNumCil.add(3);
        this.listNumCil.add(4);
        this.listNumCil.add(6);
        this.cmbNoCilindros.setItems(listNumCil);

        this.listRing.add(13);
        this.listRing.add(14);
        this.listRing.add(15);
        this.listRing.add(16);
        this.listRing.add(17);
        this.cmbTamañoRing.setItems(listRing);

        this.listLlantas.add(1);
        this.listLlantas.add(2);
        this.listLlantas.add(3);
        this.listLlantas.add(4);
        this.cmbNumeroLlantas.setItems(listLlantas);

        this.listTVeh.add("Camioneta");
        this.listTVeh.add("Automovil");
        this.cmbVehiculo.setItems(listTVeh);
        // if(this.cmbTecnicos.getItems().size()<= logicaTecnico.consultarTecnico().size()){
        for (Tecnico t : logicaTecnico.consultarTecnico()) {
            this.listTec.add(t.getNombre() + " " + t.getApellido());

        }
        System.out.println("Tamaño: " + logicaTecnico.consultarTecnico().size());
        this.cmbTecnicos.setItems(listTec);

        //}
    }

}
